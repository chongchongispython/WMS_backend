import enum


class base_enum(enum.Enum):

    @classmethod
    def get_name_list(cls):
        return [i.name for i in cls.__iter__()]

    @classmethod
    def get_value_list(cls):
        return [i.value for i in cls.__iter__()]

    @classmethod
    def get_value(cls, name):
        return cls.__getitem__(name).value


# 状态
class enum_status(base_enum):
    Forbidden = 0  # 禁用
    Normal = 1  # 正常


# 组织架构深度
class enum_organization_depth(base_enum):
    Root = 0
    Division = 1  # 处级
    Department = 2  # 部级
    Class = 3  # 课级
    Group = 4  # 组级


class enum_role(base_enum):
    ROLE1 = 2
    ROLE2 = 1


class enum_task_type(base_enum):
    EQ_LIST = 1


class enum_group_type(base_enum):
    DIVISION: 1
    DEPARTMENT: 2
    SECTION: 3
    FUNCTION: 4
    PERSONAL: 5


class enum_sub_task_type(base_enum):
    CREATED: 1
    STARTED: 2
    REJECTED: 3
    SUBMITTED: 4
    APPROVED: 5
    FINISHED: 6

class enum_participant_type(base_enum):
    REPLY: 1
    AUDIT: 2

