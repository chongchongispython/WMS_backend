from authlib.integrations.flask_oauth2 import current_token
from werkzeug.local import LocalProxy

from app import db
from app.model.user_model import user


def _get_current_user():
    _user = user.query.get(current_token['aud'])
    if not _user:
        _user = user.add_model_by_params({"work_id": current_token['aud'], "name": current_token['username']})
        db.session.commit()
    return _user


current_user = LocalProxy(_get_current_user)
