'''
200 请求成功
'''

SUCCESS_CODE = 200  # 请求成功
SUCCESS_CREATE = 201  # Created - [POST/PUT/PATCH]：用户新建或修改数据成功。
SUCCESS_DELETE = 204  # NO CONTENT - [DELETE]：用户删除数据成功。

'''
300 重定向
'''

'''
400 客户端错误
'''
ERROR_INVALID_REQUEST = 400  # INVALID REQUEST - [POST/PUT/PATCH]：用户发出的请求有错误。
ERROR_NO_PERMISSION = 401  # Unauthorized - [*]：表示用户没有权限（令牌、用户名、密码错误）。
ERROR_FORBIDDEN = 403  # Forbidden - [*] 表示用户得到授权（与401错误相对），但是访问是被禁止的。
ERROR_NOT_FOUND = 404  # NOT FOUND - [*]：用户发出的请求针对的是不存在的记录。
ERROR_NOT_ACCEPTABLE = 406  # Not Acceptable - [GET]：用户请求的格式不可得（比如用户请求JSON格式，但是只有XML格 式）。
ERROR_RESOURCE_NOT_FOUND = 410  # Gone -[GET]：用户请求的资源被永久删除，且不会再得到的。

'''
500 服务端错误
'''
SERVER_ERROR_INTERNAL = 500  # INTERNAL SERVER ERROR - [*]：服务器内部错误，无法完成请求
