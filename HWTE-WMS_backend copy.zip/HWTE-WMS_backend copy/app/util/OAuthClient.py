import requests
from authlib.integrations.flask_oauth2 import ResourceProtector
from authlib.oauth2.rfc7662 import IntrospectTokenValidator
from flask import current_app


class MyIntrospectTokenValidator(IntrospectTokenValidator):
    def introspect_token(self, token_string):
        url = current_app.config.get('MYSERVER_INTROSPECT_URL')
        data = {'token': token_string, 'token_type_hint': 'access_token'}
        auth = (current_app.config.get('MYSERVER_CLIENT_ID'), current_app.config.get('MYSERVER_CLIENT_SECRET'))
        resp = requests.post(url, data=data, auth=auth)
        resp.raise_for_status()
        return resp.json()


require_oauth = ResourceProtector()
require_oauth.register_token_validator(MyIntrospectTokenValidator())
