from flask_restx import marshal
from werkzeug.exceptions import HTTPException


class APIException(HTTPException):
    code = 400
    msg = 'Sorry, there was an unexpected error(*^v^*)'
    level = "error"

    def __init__(self, msg=None, code=None, level=None, headers="application/json"):

        self.headers = headers
        if code:
            self.code = code
        if msg:
            self.msg = msg
        if level:
            self.level = level
        super().__init__(msg, None)


class InvalidRequestError(APIException):
    code = 400
    msg = 'InvalidRequestError'
    level = "warning"


class NoPermissionError(APIException):
    code = 401
    msg = 'NoPermissionError'
    level = "warning"


class ForbiddenError(APIException):
    code = 403
    msg = 'ForbiddenError'
    level = "warning"


class NotFoundError(APIException):
    code = 404
    msg = 'NotFoundError'
    level = "warning"


class NotAcceptableError(APIException):
    code = 406
    msg = 'NotAcceptableError'
    level = "warning"


class ResourceNotFoundError(APIException):
    code = 410
    msg = 'ResourceNotFoundError'
    level = "warning"


class RaiseMarshalError(InvalidRequestError):
    code = 400
    msg = 'RaiseMarshalError'
    level = "warning"
    result = None
    fields = None

    def __init__(self, result, fields, code=None, msg=None, level=None):
        super().__init__(code=code, msg=msg, level=level)
        self.result = result
        self.fields = fields

    def marshal(self):
        data = {
            "code": self.code,
            "msg": self.msg
        }
        data.update(self.result)
        return marshal(data, self.fields)
