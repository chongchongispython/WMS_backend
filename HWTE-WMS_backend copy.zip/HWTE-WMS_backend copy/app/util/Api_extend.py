import traceback

import requests
from flask import current_app, jsonify
from flask_restx import Api
from requests import HTTPError
from sqlalchemy.exc import SQLAlchemyError, DBAPIError, NoResultFound, MultipleResultsFound
from werkzeug.exceptions import HTTPException
from werkzeug.http import HTTP_STATUS_CODES

from app import db
from app.util.Api_exceptions import APIException, RaiseMarshalError
from app.util.Api_return_codes import SUCCESS_CODE


class ExtendedAPI(Api):
    """This class overrides 'handle_error' method of 'Api' class ,
    to extend global exception handing functionality of 'flask-restful'.
    """

    def handle_error(self, err):
        """It helps preventing writing unnecessary
        try/except block though out the application
        """

        traceback.print_exc()

        log_msg = err
        log_level = getattr(err, "level", None)
        if hasattr(err, "data"):
            setattr(err, "msg", err.data)
            log_msg = err.data

        if log_level == "debug":
            current_app.logger.debug(log_msg)
        elif log_level == "info":
            current_app.logger.info(log_msg)
        elif log_level == "warning":
            current_app.logger.warning(log_msg)
        elif log_level == "error":
            current_app.logger.error(log_msg)
        elif log_level == "critical":
            current_app.logger.critical(log_msg)
        else:
            current_app.logger.warning(log_msg)

        if isinstance(err, RaiseMarshalError):
            return err.marshal(), SUCCESS_CODE

        elif isinstance(err, APIException):
            return jsonify({
                'code': err.code,
                'msg': err.msg
            }), SUCCESS_CODE

        # Handle HTTPExceptions
        elif isinstance(err, HTTPException):
            return jsonify({
                'code': err.code,
                'msg': str(dict(
                    description=getattr(err, 'description', HTTP_STATUS_CODES.get(err.code, '')),
                    body=getattr(err, 'body', HTTP_STATUS_CODES.get(err.code, '')),
                    data=getattr(err, 'data', HTTP_STATUS_CODES.get(err.code, '')),
                    msg=getattr(err, 'msg', HTTP_STATUS_CODES.get(err.code, '')),
                ))
            }), SUCCESS_CODE
        # If msg attribute is not set,
        # consider it as Python core exception and
        # hide sensitive error info from end user
        elif isinstance(err, HTTPError):
            # handle login error
            if err.response.status_code == 401:
                return jsonify({
                    'code': err.response.status_code,
                    'msg': "账号或密码错误"
                }), SUCCESS_CODE
            else:
                return jsonify({
                    'code': err.response.status_code,
                    'msg': getattr(err, 'response.status_code', HTTP_STATUS_CODES.get(err.response.status_code, ''))
                }), SUCCESS_CODE

        elif isinstance(err, SQLAlchemyError):
            # TODO distinguish errors
            if isinstance(err, DBAPIError):
                db.session.rollback()
                return jsonify({
                    'code': 406,
                    'msg': str(err.args)
                }), SUCCESS_CODE
            elif isinstance(err, NoResultFound):
                return jsonify({
                    'code': 404,
                    'msg': "query result not found"
                }), SUCCESS_CODE
            elif isinstance(err, MultipleResultsFound):
                return jsonify({
                    'code': 500,
                    'msg': "unexpected result found"
                }), SUCCESS_CODE
            else:
                return jsonify({
                    'code': 500,
                    'msg': str(err.args)
                }), SUCCESS_CODE

        elif isinstance(err, requests.RequestException):
            if isinstance(err, requests.exceptions.ConnectionError):
                return jsonify({
                    'code': 500,
                    'msg': f"{str(err)}"
                }), SUCCESS_CODE
            else:
                print(traceback.format_exc())
                return jsonify({
                    'code': 500,
                    'msg': "server internal error"
                }), SUCCESS_CODE

        elif isinstance(err, Exception):
            print(traceback.format_exc())
            return jsonify({
                'code': 500,
                'msg': "server internal error"
            }), SUCCESS_CODE

        else:
            # Handle application specific custom exceptions
            return jsonify(**err.kwargs), err.http_status_code
