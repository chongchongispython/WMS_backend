from flask_restx import Resource

from app.util.Decorators import before_entry_func, before_entry_view


class customResource(Resource):
    decorators = [before_entry_view()]
    method_decorators = [before_entry_func()]
