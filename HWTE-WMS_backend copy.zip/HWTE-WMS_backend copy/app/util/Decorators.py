from functools import wraps

from flask import g


def before_entry_func():
    '''
        setup flask g before entry function
    '''

    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            # print(getattr(fn, "__dict__"))
            # print(getattr(fn, "__doc__"))
            # print(getattr(fn, "__name__"))
            # print(getattr(fn, "__module__"))
            g.api_func_desc = (getattr(fn, "__doc__") if getattr(fn, "__doc__") else "").strip()
            return fn(*args, **kwargs)

        return decorator

    return wrapper


def before_entry_view():
    '''
        setup flask g before entry view
    '''

    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            g.api_desc = getattr(fn, "__name__", None)
            return fn(*args, **kwargs)

        return decorator

    return wrapper
