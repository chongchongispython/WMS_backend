# -*- coding: utf-8 -*-
# (C) Wu Dong, 2018
# All rights reserved


__author__ = 'Wu Dong <wudong@eastwu.cn>'
__title__ = 'pre_request'
__description__ = 'Validate request arguments, Including Cross Field, Cross Struct'
__url__ = 'https://github.com/Eastwu5788/pre-request'
__version__ = '2.1.5'
__build__ = 0x000001
__author_email__ = 'wudong@eastwu.cn'
__license__ = 'MIT License'
__copyright__ = 'Copyright 2020 Wu Dong'
__cake__ = '\u2728 \U0001f370 \u2728'
