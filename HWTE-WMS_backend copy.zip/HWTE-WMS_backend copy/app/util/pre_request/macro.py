# !/usr/local/python/bin/python
# -*- coding: utf-8 -*-
# (C) Wu Dong, 2020
# All rights reserved
# @Author: 'Wu Dong <wudong@eastwu.cn>'
# @Time: '2020-08-25 09:46'

# Project config key
K_CONTENT_TYPE = "PRE_CONTENT_TYPE"
K_FUZZY = "PRE_FUZZY"
K_STORE_KEY = "PRE_STORE_KEY"
K_SKIP_FILTER = "PRE_SKIP_FILTER"
