import datetime
from copy import deepcopy

from flask_restx import Namespace, fields
from app.util.pre_request import Rule
from app.dto import base_resource_fields, BaseDTO, BasePostStrRule, MyDateTimeFormat, BasePutStrRule, BasePostBoolRule, \
    BasePostIntRule, BasePutIntRule
# from app.dto.product_dto import ProductDTO


class PhaseDTO(object):
    api = Namespace('階段管理')

    add_phase_req = {
        "product_id": BasePostIntRule(),
        "phase_name": BasePostStrRule(dest="name"),
        "start_time": Rule(type=datetime.datetime, fmt="%Y-%m-%d %H:%M:%S", required=True),
        "end_time": Rule(type=datetime.datetime, fmt="%Y-%m-%d %H:%M:%S", required=True),
    }

    update_phase_req = {
        "phase_id": Rule(type=int, dest='id', required=True),
        "phase_name": BasePutStrRule(dest="name"),
        "product_id": BasePutIntRule(),
        "start_time": Rule(type=datetime.datetime, fmt="%Y-%m-%d %H:%M:%S", required=False, skip=True),
        "end_time": Rule(type=datetime.datetime, fmt="%Y-%m-%d %H:%M:%S", required=False, skip=True),
    }

    delete_phase_req = {
        "phase_id": Rule(type=int, dest='id', location='args', required=True),
    }

    phase_resp_dto = {
        "phase_id": fields.Integer(attribute='id'),
        "product_id": fields.Integer(attribute='product_id'),
        # "product": fields.Nested(ProductDTO.product_resp_dto, attribute="_product"),
        "phase_name": fields.String(attribute='name'),
        "start_time": MyDateTimeFormat(attribute='start_time'),
        "end_time": MyDateTimeFormat(attribute='end_time'),
        "created_by": fields.String(attribute='creator_name'),
        "created_by_account": fields.String(attribute='creator_account'),
        "updated_by": fields.String(attribute='updater_name'),
        "updated_by_account": fields.String(attribute='updater_account'),
        "created_time": MyDateTimeFormat(attribute='create_time'),
        "updated_time": MyDateTimeFormat(attribute='last_update_time')
    }

    __phase_resp_fields = deepcopy(base_resource_fields)
    __phase_resp_fields['result']['phase'] = fields.Nested(phase_resp_dto)
    phase_resp_field_model = api.model('獲取階段', __phase_resp_fields)

    __phase_name_list_resp_fields = deepcopy(base_resource_fields)
    __phase_name_list_resp_fields['result']['phase_name_list'] = fields.List(fields.String())
    phase_name_list_resp_field_model = api.model('獲取階段選單', __phase_name_list_resp_fields)
