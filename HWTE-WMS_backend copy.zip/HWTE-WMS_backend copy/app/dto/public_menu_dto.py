import json
from copy import deepcopy

from flask_restx import Namespace, fields

from app.dto import BaseDTO, base_resource_fields
from app.util.pre_request import Rule


def convert_json_to_str(val):
    return


class PublicMenuDTO(BaseDTO):
    api = Namespace('公共选单管理')

    # request body
    get_public_menus_by_params_req = {
        "menu_name": Rule(type=str, location='args', required=False),
        # "parent_id": Rule(type=int, location='args', required=False, default=None),
        "depth": Rule(type=int, location='args', required=False, default=3, gte=0, lte=10)
    }

    add_public_menu_by_params_req = {
        "menu_name": Rule(type=str, location=['args', 'json'], required=True),
        "parent_id": Rule(type=int, location=['args', 'json'], required=False),
        "menu_config": Rule(type=str, location=['args', 'json'], dest="config", required=False, json=True, callback=lambda x: json.dumps(x)),
        "is_updatable": Rule(type=bool, location=['args', 'json'], required=False, default=True),
    }

    update_public_menu_by_params_req = {
        "menu_id": Rule(type=int, location=['args', 'json'], required=True),
        "menu_name": Rule(type=str, location=['args', 'json'], required=False, skip=True),
        "parent_id": Rule(type=int, location=['args', 'json'], required=False, skip=True),
        "menu_config": Rule(type=str, location=['args', 'json'], dest="config", required=False, json=True, callback=lambda x: json.dumps(x), skip=True),
        "is_updatable": Rule(type=bool, location=['args', 'json'], required=False, skip=True),
    }

    delete_public_menu_by_params_req = {
        "menu_id": Rule(type=int, location=['args', 'json'], required=True)
    }

    # response body
    public_menu_fields = {
        "menu_id": fields.Integer(attribute='id'),
        "parent_id": fields.Integer(),
        "parent_menu_name": fields.String(attribute=lambda x: x._parent.menu_name if x.parent_id else None),
        "menu_config": fields.Raw(attribute=lambda x: json.loads(x.config) if x.config else {}),
        "menu_name": fields.String(),
        "is_updatable": fields.Boolean()
    }

    @classmethod
    def _recursive_mapping(cls, iteration_number=10):
        json_mapping = deepcopy(cls.public_menu_fields)
        if iteration_number:
            json_mapping['children'] = fields.List(fields.Nested(cls._recursive_mapping(iteration_number - 1)), attribute=lambda x: x._children)

        return cls.api.model('public_menu' + str(iteration_number), json_mapping)

    __public_menu_resp_fields = deepcopy(base_resource_fields)
    __public_menu_resp_fields['result'] = fields.Nested(public_menu_fields)
    public_menu_resp_field_model = api.model('public_menu', __public_menu_resp_fields)
