from copy import deepcopy

from flask_restx import Namespace, fields
from werkzeug import datastructures

from app.dto import BaseDTO, handleFoggySearchParam, MyDateTimeFormat, base_resource_pagination_fields, base_resource_fields
from app.dto.partnumber_dto import PartnumberDTO
from app.util.pre_request import Rule


class AssetDTO(BaseDTO):
    api = Namespace('庫存管理')

    get_asset_consumable_paginate_by_item_params_req = {
        "asset_category_id": Rule(type=int, location='args', dest='asset_category_item_id', required=False),
        "standard_name_id": Rule(type=int, location='args', dest='standard_name_item_id', required=False),
        "vendor_id": Rule(type=int, location='args', dest='vendor_item_id', required=False),
        "station_id": Rule(type=int, location='args', dest='station_item_id', required=False),
        "spec_id": Rule(type=int, location='args', dest='spec_item_id', required=False),
        "product": Rule(type=str, trim=True, location='args', required=False, callback=handleFoggySearchParam),
        "page_index": Rule(type=int, location='args', required=False),
        "per_page": Rule(type=int, location='args', required=False)
    }

    get_asset_equipment_paginate_by_item_params_req = {
        "asset_category_id": Rule(type=int, location='args', dest='asset_category_item_id', required=False),
        "standard_name_id": Rule(type=int, location='args', dest='standard_name_item_id', required=False),
        "vendor_id": Rule(type=int, location='args', dest='vendor_item_id', required=False),
        "station_id": Rule(type=int, location='args', dest='station_item_id', required=False),
        "spec_id": Rule(type=int, location='args', dest='spec_item_id', required=False),
        "product": Rule(type=str, trim=True, location='args', required=False, callback=handleFoggySearchParam),
        "asset_sn": Rule(type=str, trim=True, location='args', required=False, callback=handleFoggySearchParam),
        "page_index": Rule(type=int, location='args', required=False),
        "per_page": Rule(type=int, location='args', required=False)
    }

    post_asset_file_params_req = {
        "file": Rule(type=datastructures.FileStorage, location="form", required=True),
    }

    # request body
    asset_consumable_resp_dto = {
        "id": fields.Integer(attribute='id'),
        "partnumber": fields.Nested(PartnumberDTO.partnumber_fields, attribute="_partnumber"),
        "department": fields.String(attribute='department'),
        "product": fields.String(attribute='product'),
        "location": fields.String(attribute='location'),
        "total_qty": fields.Integer(attribute='total_qty'),
        "non_defective_qty": fields.Integer(attribute='non_defective_qty'),
        "defective_qty": fields.Integer(attribute='defective_qty'),
        "remark": fields.String(attribute='remark'),
        # "borrow_status":,
        # "borrowing_channels":,
        "created_by": fields.String(attribute='creator_name'),
        "created_by_account": fields.String(attribute='creator_account'),
        "updated_by": fields.String(attribute='updater_name'),
        "updated_by_account": fields.String(attribute='updater_account'),
        "created_time": MyDateTimeFormat(attribute='create_time'),
        "updated_time": MyDateTimeFormat(attribute='last_update_time')
    }

    asset_equipment_resp_dto = {
        "id": fields.Integer(attribute='id'),
        "partnumber": fields.Nested(PartnumberDTO.partnumber_fields, attribute="_partnumber"),
        "department": fields.String(attribute='department'),
        "product": fields.String(attribute='product'),
        "build": fields.String(attribute='build'),
        "location": fields.String(attribute='location'),
        "total_qty": fields.Integer(attribute='total_qty'),
        "usage_status": fields.String(attribute='usage_status'),
        "asset_sn": fields.String(attribute='asset_sn'),
        "control_number": fields.String(attribute='control_number'),
        "property_number": fields.String(attribute='property_number'),
        "customs_number": fields.String(attribute='customs_number'),
        "customs_filing_number": fields.String(attribute='customs_filing_number'),
        "rfid": fields.String(attribute='rfid'),
        "purchase_order": fields.String(attribute='purchase_order'),
        "remark": fields.String(attribute='remark'),
        # "borrow_status":,
        # "borrowing_channels":,
        "created_by": fields.String(attribute='creator_name'),
        "created_by_account": fields.String(attribute='creator_account'),
        "updated_by": fields.String(attribute='updater_name'),
        "updated_by_account": fields.String(attribute='updater_account'),
        "created_time": MyDateTimeFormat(attribute='create_time'),
        "updated_time": MyDateTimeFormat(attribute='last_update_time')
    }

    fail_row_resp = {
        "fail_row": fields.Integer(),
        "fail_msgs": fields.List(fields.String())
    }

    __asset_consumable_pagination_resp_fields = deepcopy(base_resource_pagination_fields)
    __asset_consumable_pagination_resp_fields['result']['asset_consumable_list'] = fields.List(
        fields.Nested(asset_consumable_resp_dto), attribute="items")
    asset_consumable_pagination_resp_fields_model = api.model('獲取資產耗材分頁列表', __asset_consumable_pagination_resp_fields)

    __asset_equipment_pagination_resp_fields = deepcopy(base_resource_pagination_fields)
    __asset_equipment_pagination_resp_fields['result']['asset_equipment_list'] = fields.List(
        fields.Nested(asset_equipment_resp_dto), attribute="items")
    asset_equipment_pagination_resp_fields_model = api.model('獲取資產設備分頁列表', __asset_equipment_pagination_resp_fields)

    __file_resp_fields = deepcopy(base_resource_fields)
    __file_resp_fields['result']['error_list'] = fields.List(fields.Nested(fail_row_resp), default=[])
    __file_resp_fields['result']['data_list'] = fields.List(fields.Nested(PartnumberDTO.partnumber_fields), default=[])
    __file_resp_fields['result']['verify_result'] = fields.Boolean(default=True)
    file_resp_fields_model = api.model('上传文件', __file_resp_fields)
