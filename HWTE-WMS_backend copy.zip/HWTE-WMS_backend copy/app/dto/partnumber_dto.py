#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
from copy import deepcopy

from flask_restx import Namespace, fields

from app.dto import base_resource_fields, BaseDTO, base_resource_pagination_fields
from app.util.pre_request import Rule


class PartnumberDTO(BaseDTO):
    api = Namespace('Partnumber管理')

    # request body
    get_partnumber_by_params_req = {
        "asset_category_id": Rule(type=int, location='args', dest='asset_category_item_id', required=True),
        "standard_name_id": Rule(type=int, location='args', dest='standard_name_item_id', required=True),
        "spec_id": Rule(type=int, location='args', dest='spec_item_id', required=True),
        "vendor_id": Rule(type=int, location='args', dest='vendor_item_id', required=True),
        "station_id": Rule(type=int, location='args', dest='station_item_id', required=True),
    }

    get_partnumbers_by_params_req = {
        "asset_category_id": Rule(type=int, location='args', dest='asset_category_item_id', required=False),
        "standard_name_id": Rule(type=int, location='args', dest='standard_name_item_id', required=False),
        "spec_id": Rule(type=int, location='args', dest='spec_item_id', required=False),
        "vendor_id": Rule(type=int, location='args', dest='vendor_item_id', required=False),
        "station_id": Rule(type=int, location='args', dest='station_item_id', required=False),
        "is_virtual": Rule(type=bool, location='args', required=False),
        "page_index": Rule(type=int, location='args', required=True),
        "per_page": Rule(type=int, location='args', required=True)
    }

    add_partnumber_by_params_req = {
        "asset_category_id": Rule(type=int, location=['args', 'json'], dest='asset_category_item_id', required=True),
        "standard_name_id": Rule(type=int, location=['args', 'json'], dest='standard_name_item_id', required=True),
        "spec_id": Rule(type=int, location=['args', 'json'], dest='spec_item_id', required=True),
        "vendor_id": Rule(type=int, location=['args', 'json'], dest='vendor_item_id', required=True),
        "station_id": Rule(type=int, location=['args', 'json'], dest='station_item_id', required=True),
        "price": Rule(type=str, location=['args', 'json'], required=True),
        "currency": Rule(type=str, location=['args', 'json'], required=True),
    }

    update_partnumber_by_params_req = {
        "partnumber_id": Rule(type=int, location=['args', 'json'], required=True),
        "price": Rule(type=str, location=['args', 'json'], required=False, skip=True),
        "currency": Rule(type=str, location=['args', 'json'], required=False, skip=True)
    }

    delete_partnumber_by_params_req = {
        "partnumber_id": Rule(type=int, location=['args', 'json'], required=True),
    }

    rebind_partnumber_by_params_req = {
        "partnumber_id": Rule(type=int, location=['args', 'json'], required=True),
        "real_partnumber_id": Rule(type=int, location=['args', 'json'], required=True)

    }

    # response body
    partnumber_fields = {
        "partnumber_id": fields.Integer(attribute='id'),
        "partnumber": fields.String(attribute='partnumber'),
        "asset_category": fields.String(attribute='_asset_category_item.item_name'),
        "standard_name": fields.String(attribute='_standard_name_item.item_name'),
        "vendor": fields.String(attribute='_vendor_item.item_name'),
        "station": fields.String(attribute='_station_item.item_name'),
        "spec": fields.String(attribute='_spec_item.item_name'),
        "asset_category_id": fields.Integer(attribute='_asset_category_item.id'),
        "standard_name_id": fields.Integer(attribute='_standard_name_item.id'),
        "vendor_id": fields.Integer(attribute='_vendor_item.id'),
        "station_id": fields.Integer(attribute='_station_item.id'),
        "spec_id": fields.Integer(attribute='_spec_item.id'),
        "zh_name": fields.String(),
        "en_name": fields.String(),
        "aqid": fields.String(),
        "vpn": fields.String(),
        "payment_method": fields.String(),
        "price": fields.String(),
        "currency": fields.String(),
        "fx_partnumber": fields.String(attribute='fx_number'),
        "is_virtual": fields.Boolean(attribute='is_virtual'),
        "physical_spec": fields.String(attribute=lambda x: "{}_{}".format(x.en_name, x._spec_item.item_name)),
    }

    __partnumbers_resp_fields = deepcopy(base_resource_pagination_fields)
    __partnumbers_resp_fields['result']['partnumber_list'] = fields.List(fields.Nested(partnumber_fields), attribute="items")
    partnumbes_resp_field_model = api.model('partnumber分頁列表', __partnumbers_resp_fields)

    __partnumber_resp_fields = deepcopy(base_resource_fields)
    __partnumber_resp_fields['result'] = fields.Nested(partnumber_fields)
    partnumber_resp_field_model = api.model('partnumber', __partnumber_resp_fields)
