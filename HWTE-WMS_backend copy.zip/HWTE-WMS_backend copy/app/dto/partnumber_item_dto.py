from copy import deepcopy

from flask_restx import Namespace, fields
from app.util.pre_request import Rule
from app.dto import base_resource_fields, BaseDTO, BasePostStrRule, MyDateTimeFormat, BasePutStrRule, BasePostBoolRule


class PartnumberItemDTO(BaseDTO):
    api = Namespace('Partnumber子項管理')

    add_partnumber_item_req = {
        "item_name": BasePostStrRule(),
        "item_type": BasePostStrRule(),
        "parent_id": Rule(type=int, required=False),
        "is_virtual": BasePostBoolRule(),
    }

    update_partnumber_item_req = {
        "partnumber_item_id": Rule(type=int, dest='id', required=True),
        "item_name": BasePutStrRule()
    }

    delete_partnumber_item_req = {
        "partnumber_item_id": Rule(type=int, dest='id', location='args', required=True),
    }

    get_partnumber_item_list_req = {
        "item_type": Rule(type=str, trim=True, location='args', required=False),
        "is_virtual": Rule(type=bool, location='args', required=False)
    }

    partnumber_item_resp_dto = {
        "item_id": fields.Integer(attribute='id'),
        "item_name": fields.String(attribute='item_name'),
        "item_type": fields.String(attribute=lambda _item: _item._partnumber_item_type.type_name),
        "item_code": fields.String(attribute='item_code'),
        "parent_id": fields.Integer(attribute='parent_id'),
        "is_virtual": fields.Boolean(attribute='is_virtual'),
        "created_by": fields.String(attribute='creator_name'),
        "created_by_account": fields.String(attribute='creator_account'),
        "updated_by": fields.String(attribute='updater_name'),
        "updated_by_account": fields.String(attribute='updater_account'),
        "created_time": MyDateTimeFormat(attribute='create_time'),
        "updated_time": MyDateTimeFormat(attribute='last_update_time')
    }

    __partnumber_list_resp_fields = deepcopy(base_resource_fields)
    __partnumber_list_resp_fields['result']['partnumber_item_list'] = fields.List(fields.Nested(partnumber_item_resp_dto))
    partnumber_list_resp_fields_model = api.model('獲取partnumber子項項表', __partnumber_list_resp_fields)

    __partnumber_resp_fields = deepcopy(base_resource_fields)
    __partnumber_resp_fields['result']['partnumber_item'] = fields.Nested(partnumber_item_resp_dto)
    partnumber_resp_field_model = api.model('獲取partnumber子項', __partnumber_resp_fields)