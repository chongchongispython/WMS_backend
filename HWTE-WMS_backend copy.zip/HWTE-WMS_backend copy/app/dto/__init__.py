from copy import deepcopy

from flask_restx import fields
from app.util.pre_request import Rule

from app.util.Api_return_codes import SUCCESS_CODE


def handleFoggySearchParam(value):
    rst = value
    if value:
        rst = f'%{value}%'
    return rst


def bool_param_transform(value: str):
    if value:
        if value.lower() == 'true':
            return True
        elif value.lower() == "false":
            return False
    return None


base_resource_fields = {
    "code": fields.Integer(default=SUCCESS_CODE),
    "msg": fields.String(default="success"),
    "result": {}
}

base_resource_pagination_fields = {
    "code": fields.Integer(default=SUCCESS_CODE),
    "msg": fields.String(default="success"),
    "result": {
        "current_page": fields.Integer(attribute="page"),
        "page_count": fields.Integer(attribute="per_page"),
        "total_page": fields.Integer(attribute="pages"),
        "total_count": fields.Integer(attribute="total"),
    }
}

delete_success_resp = {
    "code": 200,
    "msg": "Delete success"
}

base_paginate_req_params = {
    "page": Rule(type=int, location='args', required=True),
    "page_count": Rule(type=int, location='args', required=True)
}


class BaseDTO(object):
    get_row_by_id_req = {
        "id": Rule(type=int, required=True)
    }

    get_menu_resp = {
        'id': fields.Integer(attribute='id'),
        'name': fields.String(attribute='name')
    }

    menu_resp_fields = deepcopy(base_resource_fields)
    menu_resp_fields['result']['data'] = fields.List(fields.Nested(get_menu_resp))


class MyDateTimeFormat(fields.Raw):
    def format(self, value):
        if isinstance(value, str):
            return value
        return value.strftime("%Y-%m-%d %H:%M:%S")


class BasePostRule(Rule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.required = kwargs.get("required", True)


class BasePutRule(Rule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.skip = kwargs.get("skip", True)
        self.required = kwargs.get("required", False)


class BasePutStrRule(BasePutRule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.trim = kwargs.get("trim", True)
        self.direct_type = kwargs.get("type", str)
        self.reg = kwargs.get("reg", "\w+")


class BasePutIntRule(BasePutRule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.direct_type = kwargs.get("type", int)


class BasePutBoolRule(BasePutRule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.direct_type = kwargs.get("type", bool)


class BasePostStrRule(BasePostRule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.trim = kwargs.get("trim", True)
        self.direct_type = kwargs.get("type", str)
        self.reg = kwargs.get("reg", "\w+")


class BasePostIntRule(BasePostRule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.direct_type = kwargs.get("type", int)


class BasePostBoolRule(BasePostRule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.direct_type = kwargs.get("type", bool)
