import datetime
from copy import deepcopy

from flask_restx import Namespace, fields
from app.util.pre_request import Rule
from app.dto import base_resource_fields, BaseDTO, BasePostStrRule, MyDateTimeFormat, BasePutStrRule, BasePostBoolRule, \
    BasePostIntRule, base_resource_pagination_fields, handleFoggySearchParam
from app.dto.phase_dto import PhaseDTO


class ProductDTO(object):
    api = Namespace('產品管理')

    add_product_req = {
        "product_name": BasePostStrRule(dest="fx_code"),
    }

    update_product_req = {
        "product_id": Rule(type=int, dest='id', required=True),
        "product_name": BasePutStrRule(dest="fx_code"),
    }

    delete_product_req = {
        "product_id": Rule(type=int, dest='id', location='args', required=True),
    }

    get_product_paginate_by_params_req = {
        "product_name": Rule(type=str, trim=True, dest="fx_code", location='args', required=False,
                             callback=handleFoggySearchParam),
        "page_index": Rule(type=int, location='args', required=False),
        "per_page": Rule(type=int, location='args', required=False)
    }

    product_resp_dto = {
        "product_id": fields.Integer(attribute='id'),
        "product_name": fields.String(attribute='fx_code'),
        "phase_list": fields.List(fields.Nested(PhaseDTO.phase_resp_dto), attribute="_phases"),
        "created_by": fields.String(attribute='creator_name'),
        "created_by_account": fields.String(attribute='creator_account'),
        "updated_by": fields.String(attribute='updater_name'),
        "updated_by_account": fields.String(attribute='updater_account'),
        "created_time": MyDateTimeFormat(attribute='create_time'),
        "updated_time": MyDateTimeFormat(attribute='last_update_time')
    }

    __product_resp_fields = deepcopy(base_resource_fields)
    __product_resp_fields['result']['product'] = fields.Nested(product_resp_dto)
    product_resp_field_model = api.model('獲取產品', __product_resp_fields)

    __product_list_resp_fields = deepcopy(base_resource_fields)
    __product_list_resp_fields['result']['product_list'] = fields.List(fields.Nested(product_resp_dto))
    product_list_resp_field_model = api.model('獲取產品階段列表', __product_list_resp_fields)

    __product_pagination_resp_fields = deepcopy(base_resource_pagination_fields)
    __product_pagination_resp_fields['result']['product_list'] = fields.List(fields.Nested(product_resp_dto), attribute="items")
    product_pagination_resp_field_model = api.model('獲取產品階段分頁列表', __product_pagination_resp_fields)

