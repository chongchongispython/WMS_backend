import collections

import numpy as np
import pandas as pd
from pandas import DataFrame

from app import db
from app.dto.asset_dto import AssetDTO
from app.model.asset_consumable_model import AssetConsumable
from app.model.asset_equipment_model import AssetEquipment
from app.model.partnumber_item_model import PartnumberItem
from app.model.partnumber_model import Partnumber
from app.service import partnumber_service
from app.util.Api_exceptions import RaiseMarshalError


def get_asset_consumable_page_by_params(params={},
                                        page_index=1,
                                        per_page=15,
                                        orders=collections.OrderedDict()):
    result_page = AssetConsumable._get_model_sql_by_params(params=params) \
        .join(Partnumber) \
        .order_by(Partnumber.partnumber.asc()) \
        .paginate(page=page_index, per_page=per_page)
    return result_page


def get_asset_equipment_page_by_params(params={},
                                       page_index=1,
                                       per_page=15,
                                       orders=collections.OrderedDict()):
    result_page = AssetEquipment._get_model_sql_by_params(params=params) \
        .join(Partnumber) \
        .order_by(Partnumber.partnumber.asc()) \
        .order_by(AssetEquipment.asset_sn.asc()) \
        .paginate(page=page_index, per_page=per_page)
    return result_page


def __update_asset_equipment_by_file(df):
    df.replace(np.nan, '', inplace=True)
    df_dict = df.to_dict("records")

    # 将不存在于文档中AssetEquipment的sn的数量清0
    df_sn_list = [i['資產SN'] for i in df_dict]
    all_sn_list = [i[0] for i in AssetEquipment._get_model_sql_by_params().with_entities(AssetEquipment.asset_sn).distinct(AssetEquipment.asset_sn).all()]
    non_exist_sn_list = list(set(all_sn_list).difference(df_sn_list))
    for non_exist_sn in non_exist_sn_list:
        for _asset_equipment in AssetEquipment.get_model_list_by_params({"asset_sn": non_exist_sn}):
            _asset_equipment.update_model_by_params({"total_qty": 0})

    for row in df_dict:
        asset_category_item_id = PartnumberItem.get_model_by_params({"item_name": row['資產中類']}).id
        standard_name_item_id = PartnumberItem.get_model_by_params({"item_name": row['簡稱']}).id
        vendor_item_id = PartnumberItem.get_model_by_params({"item_name": row['英文廠商']}).id
        station_item_id = PartnumberItem.get_model_by_params({"item_name": row['工站']}).id
        spec_item_id = PartnumberItem.get_model_by_params({"item_name": row['規格']}).id

        params = {
            "asset_category_item_id": asset_category_item_id,
            "standard_name_item_id": standard_name_item_id,
            "vendor_item_id": vendor_item_id,
            "station_item_id": station_item_id,
            "spec_item_id": spec_item_id
        }

        _partnumber = Partnumber.get_model_by_params(params)

        eq_params = {
            "partnumber_id": _partnumber.id,
            "total_qty": 1,
            "department": row['使用部門'],
            "product": row['專案名稱'],
            "build": row['專案階段'],
            "location": row['存放位置'],
            "usage_status": row['使用狀態'],
            "asset_sn": row['資產SN'],
            "control_number": row['管制編號'],
            "property_number": row['財產編號'],
            "customs_number": row['關務編號'],
            "customs_filing_number": row['關務歸檔號'],
            "rfid": row['RFID'],
            "purchase_order": row['採購編號'],
            "remark": row['備註'],
        }

        _asset_equipment: AssetEquipment
        _asset_equipment = AssetEquipment.get_model_by_params({"asset_sn": row['資產SN'], "total_qty": 1}, check=False)
        if _asset_equipment:
            if _asset_equipment.partnumber_id == _partnumber.id:
                _asset_equipment.update_model_by_params(eq_params)
            else:
                # 将sn相同，partnumber不同的数量清0，同时添加新的资产
                _asset_equipment.update_model_by_params({"total_qty": 0})
                AssetEquipment.add_model_by_params(eq_params)
        else:
            AssetEquipment.add_model_by_params(eq_params)


def __update_asset_consumable_by_file(df):
    df.replace(np.nan, '', inplace=True)

    df.sort_values(by='創建時間', inplace=True)
    df.replace(np.nan, '', inplace=True)

    df_partnumber_id_list = []
    df_group = df.groupby(['專案名稱', '規格'])
    for name, group in df_group:
        sum_rst = group.agg({"庫存量": "sum", "良品數量": "sum", "不良品數量": "sum", })
        df_dict = group.to_dict("records")

        latest_row = df_dict[-1]

        asset_category_item_id = PartnumberItem.get_model_by_params({"item_name": latest_row['類別名稱']}).id
        standard_name_item_id = PartnumberItem.get_model_by_params({"item_name": latest_row['資產小類']}).id
        vendor_item_id = PartnumberItem.get_model_by_params({"item_name": latest_row['廠商（英文）']}).id
        station_item_id = PartnumberItem.get_model_by_params({"item_name": latest_row['工站']}).id
        spec_item_id = PartnumberItem.get_model_by_params({"item_name": latest_row['規格']}).id

        params = {
            "asset_category_item_id": asset_category_item_id,
            "standard_name_item_id": standard_name_item_id,
            "vendor_item_id": vendor_item_id,
            "station_item_id": station_item_id,
            "spec_item_id": spec_item_id
        }

        _partnumber = Partnumber.get_model_by_params(params)
        df_partnumber_id_list.append(_partnumber.id)
        cs_params = {
            "partnumber_id": _partnumber.id,
            "department": "",
            "product": latest_row['專案名稱'],
            "location": latest_row['存放位置'],
            "total_qty": sum_rst['庫存量'],
            "non_defective_qty": sum_rst['良品數量'],
            "defective_qty": sum_rst['不良品數量'],
            "remark": ""
        }

        _asset_consumable: AssetConsumable
        _asset_consumable = AssetConsumable.get_model_by_params({"product": cs_params['product'], "partnumber_id": cs_params['partnumber_id']}, check=False)
        if _asset_consumable:
            _asset_consumable.update_model_by_params(cs_params)
        else:
            AssetConsumable.add_model_by_params(cs_params)

    # 将不存在于文档中AssetConsumable的partnumber的数量清0
    all_partnumber_id_list = [i[0] for i in AssetConsumable._get_model_sql_by_params().with_entities(AssetConsumable.partnumber_id).distinct(AssetConsumable.partnumber_id).all()]
    non_exist_partnumber_id_list = list(set(all_partnumber_id_list).difference(df_partnumber_id_list))
    for non_exist_partnumber_id in non_exist_partnumber_id_list:
        for _asset_consumable in AssetConsumable.get_model_list_by_params({"partnumber_id": non_exist_partnumber_id}):
            _asset_consumable.update_model_by_params({"total_qty": 0, "non_defective_qty": 0, "defective_qty": 0})


def update_asset_equipment_by_file(file):
    df = pd.read_excel(file)
    colunms = ['資產中類',
               '簡稱',
               '規格',
               '英文廠商',
               '工站',
               '使用部門',
               '專案名稱',
               '專案階段',
               '存放位置',
               '使用狀態',
               '資產SN',
               '管制編號',
               '財產編號',
               '關務編號',
               '關務歸檔號',
               'RFID',
               '採購編號',
               '備註']
    __check_df_column(df, colunms)

    partnumber_service.update_partnumber_item_by_file(df, file_type="EQ_FILE")
    add_partnumber_list = partnumber_service.update_partnumber_by_file(df, file_type="EQ_FILE")
    __update_asset_equipment_by_file(df)
    db.session.commit()

    return {
        "data_list": add_partnumber_list,
    }


def update_asset_consumable_by_file(file):
    df = pd.read_excel(file)

    colunms = [
        '類別名稱',
        '資產小類',
        '廠商（英文）',
        '工站',
        '規格',
        '專案名稱',
        '存放位置',
        '庫存量',
        '良品數量',
        '不良品數量'
    ]
    __check_df_column(df, colunms)

    partnumber_service.update_partnumber_item_by_file(df, file_type="CS_FILE")
    add_partnumber_list = partnumber_service.update_partnumber_by_file(df, file_type="CS_FILE")
    __update_asset_consumable_by_file(df)
    db.session.commit()

    return {
        "data_list": add_partnumber_list,
    }


def __check_df_column(df: DataFrame, check_columns: list):
    if not set(check_columns).issubset(df.columns):
        msg = "Column {} not found! Check fail!".format(set(check_columns).difference(df.columns))
        raise RaiseMarshalError(fields=AssetDTO.file_resp_fields_model, result={}, msg=msg)
