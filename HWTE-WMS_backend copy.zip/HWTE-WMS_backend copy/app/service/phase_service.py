from app import db
from app.model.phase_model import Phase


def add_phase(params):
    new_phase = Phase.add_model_by_params(params)
    db.session.commit()
    return new_phase


def update_phase(params):
    _phase = get_phase_by_id(params['id']).update_model_by_params(params)
    db.session.commit()
    return _phase


def delete_phase(phase_id):
    Phase.delete_model_by_id(phase_id)
    db.session.commit()


def get_phase_by_id(phase_id):
    return Phase.get_model_by_id(phase_id)


def get_phases_list_by_params(params={}, orders={"create_time": "desc"}):
    return Phase.get_model_list_by_params(params, orders=orders)


def get_phases_menu():
    phases_name_list = db.session.query(Phase.name).distinct().all()
    return [_[0] for _ in phases_name_list]