import collections

from app import db
from app.model.product_model import Product


def add_product(data):
    new_product = Product.add_model_by_params(data)
    db.session.commit()
    return new_product


def update_product(data):
    target_product = get_product_by_id(data.get('id')).update_model_by_params(data)
    db.session.commit()
    return target_product


def delete_product(product_id):
    Product.delete_model_by_id(product_id)
    db.session.commit()


def get_product_by_id(product_id):
    return Product.get_model_by_id(product_id)


def get_products_page_by_params(params={},
                                page_index=1,
                                per_page=15,
                                orders=collections.OrderedDict({"create_time": "desc"})):
    return Product.get_model_list_by_params_paginate(params=params,
                                                     page_index=page_index,
                                                     per_page=per_page,
                                                     orders=orders)


def get_products_list_by_params(params={}, orders=collections.OrderedDict({"create_time": "desc"})):
    return Product.get_model_list_by_params(params, orders=orders)


def get_products_menu(orders=collections.OrderedDict({"create_time": "desc"})):
    products = get_products_list_by_params(orders)
    return [{"id": prod.id, "name": prod.fx_code} for prod in products]




