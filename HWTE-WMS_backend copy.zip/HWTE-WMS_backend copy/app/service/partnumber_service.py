import numpy as np

from app import db
from app.dto.asset_dto import AssetDTO
from app.model.asset_consumable_model import AssetConsumable
from app.model.asset_equipment_model import AssetEquipment
from app.model.partnumber_item_model import PartnumberItem
from app.model.partnumber_item_type_model import PartnumberItemType
from app.model.partnumber_model import Partnumber
from app.util.Api_exceptions import RaiseMarshalError
from app.util.Api_return_codes import SUCCESS_CODE

EQ_FILE = "EQ_FILE"
CS_FILE = "CS_FILE"


def get_partnumber_paginate_by_params(params, ignores=[], orders={}):
    return Partnumber.get_model_list_by_params_paginate(params=params,
                                                        page_index=params['page_index'],
                                                        per_page=params['per_page'],
                                                        ignores=ignores,
                                                        orders=orders)


def get_partnumber_list_by_params(params, ignores=[], orders={}):
    return Partnumber.get_model_list_by_params(params=params,
                                               ignores=ignores,
                                               orders=orders)


def get_partnumber_by_params(params):
    return Partnumber.get_model_by_params(params=params)


def add_partnumber_by_params(params):
    new_partnumber = Partnumber.add_model_by_params(params)
    db.session.commit()
    return new_partnumber


def update_partnumber_by_id(id, params, ignores=[]):
    _partnumber = Partnumber.get_model_by_id(id).update_model_by_params(params, ignores=ignores)
    db.session.commit()
    return _partnumber


def delete_partnumber_by_id(id):
    Partnumber.delete_model_by_id(id)
    db.session.commit()


def rebind_partnumber_by_id(rebind_id, target_id):
    _rebind_partnumber = Partnumber.get_model_by_id(rebind_id)
    _target_partnumber = Partnumber.get_model_by_id(target_id)

    # rebind AssetConsumable
    _assetConsumables = AssetConsumable._get_model_sql_by_params(
        {"partnumber_id": _rebind_partnumber.id}).with_for_update(read=False).all()
    for _assetConsumable in _assetConsumables:
        _assetConsumable.update_model_by_params({"partnumber_id": _target_partnumber.id})

    # rebind AssetEquipment
    _assetEquipments = AssetEquipment._get_model_sql_by_params(
        {"partnumber_id": _rebind_partnumber.id}).with_for_update(read=False).all()
    for _assetEquipment in _assetEquipments:
        _assetEquipment.update_model_by_params({"partnumber_id": _target_partnumber.id})

    # TODO rebind eq list 业务

    # delete _rebind_partnumber`s partnumber item which is "is_virtual"
    # delete _rebind_partnumber
    for _item in _rebind_partnumber.partnumber_items:
        if _item.is_virtual: PartnumberItem.delete_model_by_id(_item.id)

    Partnumber.delete_model_by_id(_rebind_partnumber.id)

    db.session.commit()
    return _target_partnumber


def update_partnumber_item_by_file(df, file_type):
    all_added_items = {}
    error_dict = {}

    if file_type == EQ_FILE:
        check_col_name = "check_col_eq_name"
    elif file_type == CS_FILE:
        check_col_name = "check_col_cs_name"
    else:
        raise

    check_col_name_list = []
    for _partnumber_item_type in PartnumberItemType.get_model_list_by_params(params={"is_check": True},
                                                                             orders={"level": "asc"}):
        _partnumber_items = PartnumberItem.get_model_list_by_params({"item_type_id": _partnumber_item_type.id})
        _partnumber_item_names = [i.item_name for i in _partnumber_items]

        # print(_partnumber_item_type)
        col_name = getattr(_partnumber_item_type, check_col_name)
        check_col_name_list.append(col_name)
        df[f'{col_name}_check_rst'] = np.where(df[col_name].isin(_partnumber_item_names), True, False)

    # start check excel -----------------
    error_msg = "\n"
    check_flag = True
    for _check_col_name in check_col_name_list:
        if df[f'{_check_col_name}_check_rst'].all():
            continue

        check_flag = False
        for index, row in df[df[f'{_check_col_name}_check_rst'].values == False].iterrows():
            if error_dict.get(index + 2):
                error_dict[index + 2]['fail_msgs'].append("Column:{} Value:{} 未找到!".format(_check_col_name, row[_check_col_name]))
            else:
                error_dict[index + 2] = {}
                error_dict[index + 2]['fail_msgs'] = []
                error_dict[index + 2]['fail_msgs'].append("Column:{} Value:{} 未找到!".format(_check_col_name, row[_check_col_name]))

            error_msg += f"Column:<{_check_col_name}> row:<{index + 2}> value:<{row[_check_col_name]}> check fail!\n"

    if not check_flag:
        error_list = [{
            "fail_row": k,
            "fail_msgs": v['fail_msgs']
        } for k, v in error_dict.items()]

        data = {
            "verify_result": check_flag,
            "error_list": sorted(error_list, key=lambda x: x['fail_row']),
        }
        raise RaiseMarshalError(fields=AssetDTO.file_resp_fields_model, result=data, code=SUCCESS_CODE, msg="Validate fail")

    # finish check excel -----------------

    df_dict = df.to_dict("records")
    for _partnumber_item_type in PartnumberItemType.get_model_list_by_params(params={"is_check": False},
                                                                             orders={"level": "asc"}):

        added_items = []
        col_name = getattr(_partnumber_item_type, check_col_name)
        for row in df_dict:
            _latest_partnumber_item = PartnumberItem._get_model_sql_by_params(
                {"item_type_id": _partnumber_item_type.id}, orders={"item_code": "desc"}).first()
            params = {"item_name": row[col_name], "item_type_id": _partnumber_item_type.id, "item_code": 1,
                      "parent_id": None, "is_virtual": False}

            if _partnumber_item_type.parent_id:
                _parent_partnumber_item_type = PartnumberItemType.get_model_by_id(_partnumber_item_type.parent_id)
                parent_col_name = getattr(_parent_partnumber_item_type, check_col_name)
                _parent_partnumber_item = PartnumberItem.get_model_by_params({"item_name": row[parent_col_name]})
                if not _parent_partnumber_item: raise
                params["parent_id"] = _parent_partnumber_item.id
                _latest_partnumber_item = PartnumberItem._get_model_sql_by_params(
                    {"item_type_id": _partnumber_item_type.id, "parent_id": _parent_partnumber_item.id},
                    orders={"item_code": "desc"}).first()

            if (params['parent_id'], params['item_name']) in added_items or PartnumberItem.get_model_by_params(
                    {"item_name": params['item_name']}, check=False):
                continue

            if _latest_partnumber_item:
                params['item_code'] = _latest_partnumber_item.item_code + 1

            PartnumberItem.add_model_by_params(params)
            added_items.append((params['parent_id'], params['item_name']))
            print(added_items)

        all_added_items[_partnumber_item_type.type_name] = added_items
    print(all_added_items)


def update_partnumber_by_file(df, file_type):
    # df = pd.read_excel("/Users/hwte/Downloads/301test.xlsx")
    df.sort_values(by='創建時間', inplace=True)
    df_dict = df.to_dict("records")

    eq_file_col_names = {
        "asset_category_item_id": "資產中類",
        "standard_name_item_id": "簡稱",
        "vendor_item_id": "英文廠商",
        "station_item_id": "工站",
        "spec_item_id": "規格",
        "zh_name": "中文品名",
        "en_name": "英文品名",
        "aqid": None,
        "vpn": None,
        "payment_method": "付費方式",
        "price": "價格",
        "currency": "幣別",
        "fx_number": "料號"
    }

    cs_file_col_names = {
        "asset_category_item_id": "類別名稱",
        "standard_name_item_id": "資產小類",
        "vendor_item_id": "廠商（英文）",
        "station_item_id": "工站",
        "spec_item_id": "規格",
        "zh_name": "品名（中文）",
        "en_name": "品名（英文）",
        "aqid": None,
        "vpn": None,
        "payment_method": "付費方式",
        "price": "單價",
        "currency": "幣別",
        "fx_number": "料號"
    }

    add_partnumber_list = []

    if file_type == EQ_FILE:
        file_col_names = eq_file_col_names
    elif file_type == CS_FILE:
        file_col_names = cs_file_col_names
    else:
        raise

    for row in df_dict:
        asset_category_item_id = PartnumberItem.get_model_by_params(
            {"item_name": row[file_col_names['asset_category_item_id']]}).id
        standard_name_item_id = PartnumberItem.get_model_by_params(
            {"item_name": row[file_col_names['standard_name_item_id']]}).id
        vendor_item_id = PartnumberItem.get_model_by_params({"item_name": row[file_col_names['vendor_item_id']]}).id
        station_item_id = PartnumberItem.get_model_by_params({"item_name": row[file_col_names['station_item_id']]}).id
        spec_item_id = PartnumberItem.get_model_by_params({"item_name": row[file_col_names['spec_item_id']]}).id

        search_params = {
            "asset_category_item_id": asset_category_item_id,
            "standard_name_item_id": standard_name_item_id,
            "vendor_item_id": vendor_item_id,
            "station_item_id": station_item_id,
            "spec_item_id": spec_item_id
            # "zh_name": row[file_col_names['zh_name']],
            # "en_name": row[file_col_names['en_name']],
            # "aqid": "",
            # "vpn": "",
            # "payment_method": row['付費方式'],
            # "price": row['價格'],
            # "currency": row['幣別'],
            # "fx_number": row['料號']
        }

        _partnumber: Partnumber
        _partnumber = Partnumber.get_model_by_params(search_params, check=False)

        update_params = {}
        for key, val in file_col_names.items():
            if key in ["zh_name", "en_name", "aqid", "vpn", "payment_method", "price", "currency", "fx_number"]:
                update_params[key] = str(row[val]) if val else ""

        if _partnumber:
            _partnumber_dict = _partnumber.to_dict(show=["zh_name",
                                                         "en_name",
                                                         "aqid",
                                                         "vpn",
                                                         "payment_method",
                                                         "price",
                                                         "currency",
                                                         "fx_number"])
            if not _partnumber_dict == update_params:
                _partnumber.update_model_by_params(update_params)
        else:
            update_params.update(search_params)

            new_partnumber = Partnumber.add_model_by_params(update_params)
            add_partnumber_list.append(new_partnumber)

    return add_partnumber_list
    # print(all_added_items)
    # db.session.commit()
