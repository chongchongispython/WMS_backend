from app import db
from app.model.public_menu_model import PublicMenu


def get_public_menu_list_by_params(params, ignores=[], orders={},skip_none=True):
    return PublicMenu.get_model_list_by_params(params=params,
                                               ignores=ignores,
                                               skip_none=skip_none,
                                               orders=orders)


def add_public_menu_by_params(params):
    new_public_menu = PublicMenu.add_model_by_params(params)
    db.session.commit()
    return new_public_menu


def update_public_menu_by_id(id, params, ignores=[]):
    _public_menu = PublicMenu.get_model_by_id(id).update_model_by_params(params, ignores=ignores)
    db.session.commit()
    return _public_menu


def delete_public_menu_by_id(id):
    PublicMenu.delete_model_by_id(id)
    db.session.commit()
