import collections

from app import db
from app.model.partnumber_item_model import PartnumberItem
from app.model.partnumber_item_type_model import PartnumberItemType
from app.util.Api_exceptions import APIException


def add_partnumber_item(data):
    _partnumber_item_type = PartnumberItemType.get_model_by_params({'type_name': data.get('item_type')})

    _latest_partnumber_item = PartnumberItem._get_model_sql_by_params(
        {"item_type_id": _partnumber_item_type.id, 'is_virtual': data.get('is_virtual')},
        orders={"item_code": "desc"}).first()
    params = {"item_name": data.get('item_name'), "item_type_id": _partnumber_item_type.id,
              "item_code": 1, "parent_id": data.get('parent_id'), "is_virtual": data.get('is_virtual')}

    # 檢查
    # 如果item_type為二級，則傳入參數parent_id必須要傳否則報錯400, 傳了找不到到報404
    # 如果item_type為一級，則傳入參數parent_id必須為空否則報錯400,
    # _parent_partnumber_item的item_type_id必須等於_parent_partnumber_item_type.id, 否則報錯400
    if _partnumber_item_type.parent_id:
        if not data.get('parent_id'):
            raise APIException(msg=f'partnumber item in level2 item type must have parent_id argument', code=400, level='info')
        _parent_partnumber_item_type = PartnumberItemType.get_model_by_id(_partnumber_item_type.parent_id)
        _parent_partnumber_item = PartnumberItem.get_model_by_id(data.get('parent_id'))
        if not _parent_partnumber_item:
            error_parent_id = data.get('parent_id')
            raise APIException(msg=f'parent item id={error_parent_id} not found', code=404, level='info')
        if _parent_partnumber_item.item_type_id != _parent_partnumber_item_type.id:
            raise APIException(msg=f'item_type id of parent partnumber_item not match parent partnumber_item_type id', code=400, level='info')
        _latest_partnumber_item = PartnumberItem._get_model_sql_by_params(
            {"item_type_id": _partnumber_item_type.id, "parent_id": _parent_partnumber_item.id,
             'is_virtual': data.get('is_virtual')},
            orders={"item_code": "desc"}).first()

    if _latest_partnumber_item:
        params['item_code'] = _latest_partnumber_item.item_code + 1

    new_pn_item = PartnumberItem.add_model_by_params(params)
    db.session.commit()
    return new_pn_item


def update_partnumber_item(data):
    target_partnmber_item = PartnumberItem.get_model_by_id(data.get('id')).update_model_by_params(data)
    db.session.commit()
    return target_partnmber_item


def delete_partnumber_item(partnumber_item_id):
    PartnumberItem.delete_model_by_id(partnumber_item_id)
    db.session.commit()


def get_partnumber_item_list_by_params(params={}, orders=collections.OrderedDict({"item_code": "asc"})):
    return PartnumberItem.get_model_list_by_params(params, orders=orders)


def _get_partnumber_item_type_list_by_params(params={}):
    return PartnumberItemType.get_model_list_by_params({'type_name': params.get('item_type')})

def _get_partnumber_item_type_by_params(params={}):
    return PartnumberItemType.get_model_by_params({'type_name': params.get('item_type')})


def get_partnumber_item_by_id(partnumber_item_id):
    return PartnumberItem.get_model_by_id(partnumber_item_id)
