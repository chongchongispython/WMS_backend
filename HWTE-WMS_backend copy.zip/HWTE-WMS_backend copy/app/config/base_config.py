#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import os

api_config = {
    'title': '用户权限认证服务 API',
    'version': '1.0',
    'description': '所有与用户相关的 RESTful API 服务'
}


class Config(object):
    SECRET_KEY = '5e8bca1c9aaa34aed6d069be3dfccd31'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    MYSERVER_CLIENT_ID = os.getenv('MYSERVER_CLIENT_ID') or "Lc1Iz0ta2LNyaAvFycw8zLeB"
    MYSERVER_CLIENT_SECRET = os.getenv('MYSERVER_CLIENT_SECRET') or "vVedQDE2ri0TlAHh9QoMe0i6oOyFa6TXPi2IdNuNbCJLbqFM"
    MYSERVER_BASE_URL = os.getenv('MYSERVER_BASE_URL') or 'http://127.0.0.1:5001'
    MYSERVER_USER_PROVIDER_URL = os.getenv('MYSERVER_USER_PROVIDER_URL') or 'http://127.0.0.1:5001/central_user_api'
    MYSERVER_ACCESS_TOKEN_URL = os.getenv('MYSERVER_ACCESS_TOKEN_URL') or 'http://127.0.0.1:5001/central_user_api/oauth/token'
    MYSERVER_INTROSPECT_URL = os.getenv('MYSERVER_INTROSPECT_URL') or 'http://127.0.0.1:5001/central_user_api/oauth/introspect'

    PRE_FUZZY = True
    PRE_STORE_KEY = "pp"
    PRE_CONTENT_TYPE = "application/json"
    PRE_SKIP_FILTER = False
