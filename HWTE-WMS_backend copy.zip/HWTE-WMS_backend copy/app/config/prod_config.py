#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

from app.config.base_config import Config


class ProdConfig(Config):
    pass
