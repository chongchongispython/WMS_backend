#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import os

from app.config.base_config import Config


class DevConfig(Config):
    SQLALCHEMY_DATABASE_NAME = os.getenv('SQLALCHEMY_DATABASE_NAME') or "hwte_wms_dev"  # 数据库名
    SQLALCHEMY_DATABASE_USER = os.getenv('SQLALCHEMY_DATABASE_USER') or "root"  # 数据库登录用户
    SQLALCHEMY_DATABASE_PASSWORD = os.getenv('SQLALCHEMY_DATABASE_PASSWORD') or "dpbg123."  # 数据库登录密码
    SQLALCHEMY_DATABASE_ADDRESS = os.getenv('SQLALCHEMY_DATABASE_ADDRESS') or "127.0.0.1"  # 数据库远程地址

    SQLALCHEMY_DATABASE_PORT = os.getenv('SQLALCHEMY_DATABASE_PORT') or "3306"  # 数据库远程端口
    SQLALCHEMY_DATABASE_URI = f"mysql+pymysql://{SQLALCHEMY_DATABASE_USER}:{SQLALCHEMY_DATABASE_PASSWORD}@{SQLALCHEMY_DATABASE_ADDRESS}:{SQLALCHEMY_DATABASE_PORT}/{SQLALCHEMY_DATABASE_NAME}"

    # SQLALCHEMY_DATABASE_URI = 'sqlite:////tmp/test.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    # SQLALCHEMY_COMMIT_ON_TEARDOWN = True

    MYSERVER_CLIENT_ID = os.getenv('MYSERVER_CLIENT_ID') or "Lc1Iz0ta2LNyaAvFycw8zLeB"
    MYSERVER_CLIENT_SECRET = os.getenv('MYSERVER_CLIENT_SECRET') or "vVedQDE2ri0TlAHh9QoMe0i6oOyFa6TXPi2IdNuNbCJLbqFM"
    MYSERVER_BASE_URL = os.getenv('MYSERVER_BASE_URL') or 'http://10.175.94.184:5010'
    MYSERVER_USER_PROVIDER_URL = os.getenv('MYSERVER_USER_PROVIDER_URL') or 'http://10.175.94.184:5010/central_user_api'
    MYSERVER_ACCESS_TOKEN_URL = os.getenv(
        'MYSERVER_ACCESS_TOKEN_URL') or 'http://10.175.94.184:5010/central_user_api/oauth/token'
    MYSERVER_INTROSPECT_URL = os.getenv(
        'MYSERVER_INTROSPECT_URL') or 'http://10.175.94.184:5010/central_user_api/oauth/introspect'
