from app.dto import base_resource_pagination_fields
from app.dto.partnumber_dto import PartnumberDTO
from app.service import partnumber_service
from app.util.Api_base_resource import customResource
from app.util.OAuthClient import require_oauth

from app.util.pre_request import pre

api = PartnumberDTO.api


@api.route('')
class Partnumber(customResource):

    @require_oauth('server')
    @api.marshal_with(PartnumberDTO.partnumber_resp_field_model)
    @pre.catch(PartnumberDTO.get_partnumber_by_params_req)
    def get(self, params):
        """
            获取单个partnumber
        """
        return {'result': partnumber_service.get_partnumber_by_params(params)}

    @require_oauth('server')
    @api.marshal_with(PartnumberDTO.partnumber_resp_field_model)
    @pre.catch(post=PartnumberDTO.add_partnumber_by_params_req)
    def post(self, params):
        """
            添加partnumber
        """
        return {'result': partnumber_service.add_partnumber_by_params(params)}

    @require_oauth('server')
    @api.marshal_with(PartnumberDTO.partnumber_resp_field_model)
    @pre.catch(PartnumberDTO.update_partnumber_by_params_req)
    def put(self, params):
        """
            编辑partnumber
        """
        return {'result': partnumber_service.update_partnumber_by_id(params['partnumber_id'], params)}

    @require_oauth('server')
    @api.marshal_with(base_resource_pagination_fields)
    @pre.catch(PartnumberDTO.delete_partnumber_by_params_req)
    def delete(self, params):
        """
            删除partnumber
        """
        partnumber_service.delete_partnumber_by_id(params['partnumber_id'])
        return


@api.route('/page')
class PartnumberList(customResource):

    @require_oauth('server')
    @api.marshal_with(PartnumberDTO.partnumbes_resp_field_model)
    @pre.catch(get=PartnumberDTO.get_partnumbers_by_params_req)
    def get(self, params):
        """
            获取partnumber分頁列表
        """
        return partnumber_service.get_partnumber_paginate_by_params(params, orders={"partnumber": "asc"})


@api.route('/binding')
class PartnumberBind(customResource):

    @require_oauth('server')
    @api.marshal_with(PartnumberDTO.partnumber_resp_field_model)
    @pre.catch(PartnumberDTO.rebind_partnumber_by_params_req)
    def put(self, params):
        """
            绑定partnumber
        """
        return {'result': partnumber_service.rebind_partnumber_by_id(params['partnumber_id'], params['real_partnumber_id'])}
