from app.dto.product_dto import ProductDTO
from app.util.pre_request import pre
from app.dto import base_resource_fields, delete_success_resp
from app.service import product_service
from app.util.Api_base_resource import customResource
from app.util.OAuthClient import require_oauth
from app.util.enums import enum_role

api = ProductDTO.api

@api.route('')
class Product(customResource):

    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(ProductDTO.product_resp_field_model)
    @pre.catch(post=ProductDTO.add_product_req)
    def post(self, params):
        """
            新增
        """
        return {'product': product_service.add_product(params)}


    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(ProductDTO.product_resp_field_model)
    @pre.catch(put=ProductDTO.update_product_req)
    def put(self, params):
        """
            修改
        """
        return {'product': product_service.update_product(params)}


    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(base_resource_fields)
    @pre.catch(ProductDTO.delete_product_req)
    def delete(self, params):
        """
            刪除
        """
        product_service.delete_product(params.get("id"))
        return delete_success_resp


@api.route('/list')
class ProductList(customResource):

    @require_oauth('server')
    @api.marshal_with(ProductDTO.product_list_resp_field_model)
    def get(self):
        """
            獲取全部產品階段列表
        """
        return {'product_list': product_service.get_products_list_by_params()}


@api.route('/page')
class ProductPage(customResource):

    @require_oauth('server')
    @api.marshal_with(ProductDTO.product_pagination_resp_field_model)
    @pre.catch(get=ProductDTO.get_product_paginate_by_params_req)
    def get(self, params):
        """
            獲取產品階段分頁列表
        """
        return product_service.get_products_page_by_params(params, page_index=params['page_index'],
                                                                    per_page=params['per_page'])