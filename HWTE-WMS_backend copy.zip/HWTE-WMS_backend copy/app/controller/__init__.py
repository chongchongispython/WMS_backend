from app.controller.asset_controller import api as asset
from app.controller.partnumber_controller import api as partnumber
from app.controller.public_menu_controller import api as public_menu
from app.controller.partnumber_item_controller import api as partnumber_item
from app.controller.phase_controller import api as phase
from app.controller.product_controller import api as product
