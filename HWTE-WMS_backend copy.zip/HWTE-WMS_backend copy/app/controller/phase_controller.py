from app.dto.phase_dto import PhaseDTO
from app.util.pre_request import pre
from app.dto import base_resource_fields, delete_success_resp
from app.service import phase_service
from app.util.Api_base_resource import customResource
from app.util.OAuthClient import require_oauth
from app.util.enums import enum_role

api = PhaseDTO.api

@api.route('')
class Phase(customResource):

    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(PhaseDTO.phase_resp_field_model)
    @pre.catch(post=PhaseDTO.add_phase_req)
    def post(self, params):
        """
            新增
        """
        return {'phase': phase_service.add_phase(params)}


    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(PhaseDTO.phase_resp_field_model)
    @pre.catch(put=PhaseDTO.update_phase_req)
    def put(self, params):
        """
            修改
        """
        return {'phase': phase_service.update_phase(params)}


    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(base_resource_fields)
    @pre.catch(PhaseDTO.delete_phase_req)
    def delete(self, params):
        """
            刪除
        """
        phase_service.delete_phase(params.get("id"))
        return delete_success_resp

@api.route('/menu')
class PhaseMenu(customResource):

    @require_oauth('server')
    @api.marshal_with(PhaseDTO.phase_name_list_resp_field_model)
    def get(self):
        """
            獲取全部階段選單
        """
        return {'phase_name_list': phase_service.get_phases_menu()}