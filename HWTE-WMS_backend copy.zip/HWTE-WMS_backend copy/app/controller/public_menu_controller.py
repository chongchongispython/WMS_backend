from copy import deepcopy

from flask_restx import fields, marshal

from app.dto import base_resource_pagination_fields, base_resource_fields
from app.dto.public_menu_dto import PublicMenuDTO
from app.service import public_menu_service
from app.util.Api_base_resource import customResource
from app.util.OAuthClient import require_oauth
from app.util.pre_request import pre

api = PublicMenuDTO.api
resource_fields = deepcopy(base_resource_pagination_fields)


@api.route('')
class PublicMenu(customResource):

    @require_oauth('server')
    @api.marshal_with(PublicMenuDTO.public_menu_resp_field_model)
    @pre.catch(post=PublicMenuDTO.add_public_menu_by_params_req)
    def post(self, params):
        """
            添加公用選單
        """
        return {'result': public_menu_service.add_public_menu_by_params(params)}

    @require_oauth('server')
    @api.marshal_with(PublicMenuDTO.public_menu_resp_field_model)
    @pre.catch(PublicMenuDTO.update_public_menu_by_params_req)
    def put(self, params):
        """
            修改公用選單
        """
        return {'result': public_menu_service.update_public_menu_by_id(params['menu_id'], params)}

    @require_oauth('server')
    @api.marshal_with(base_resource_fields)
    @pre.catch(PublicMenuDTO.delete_public_menu_by_params_req)
    def delete(self, params):
        """
            刪除公用選單
        """
        public_menu_service.delete_public_menu_by_id(params['menu_id'])
        return


@api.route('/list')
class PublicMenuList(customResource):

    @require_oauth('server')
    @pre.catch(get=PublicMenuDTO.get_public_menus_by_params_req)
    def get(self, params):
        """
            獲取公用選單列表
        """

        # deside filter menu_name or parent_id
        if not params['menu_name']:
            params['parent_id'] = None
            params.pop('menu_name')

        resource_fields['result']['type_list'] = fields.List(fields.Nested(PublicMenuDTO._recursive_mapping(iteration_number=params['depth'])))
        return marshal({"type_list": public_menu_service.get_public_menu_list_by_params(params, skip_none=False)}, resource_fields, skip_none=True)
