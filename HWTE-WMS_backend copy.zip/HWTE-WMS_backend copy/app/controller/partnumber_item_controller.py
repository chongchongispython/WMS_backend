from app.dto.partnumber_item_dto import PartnumberItemDTO
from app.service import partnumber_item_service
from app.util.pre_request import pre
from app.dto import base_resource_fields, delete_success_resp
from app.util.Api_base_resource import customResource
from app.util.OAuthClient import require_oauth
from app.util.enums import enum_role

api = PartnumberItemDTO.api

@api.route('')
class PartnumberItem(customResource):

    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(PartnumberItemDTO.partnumber_resp_field_model)
    @pre.catch(post=PartnumberItemDTO.add_partnumber_item_req)
    def post(self, params):
        """
            新增
        """
        return {'partnumber_item': partnumber_item_service.add_partnumber_item(params)}


    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(PartnumberItemDTO.partnumber_resp_field_model)
    @pre.catch(put=PartnumberItemDTO.update_partnumber_item_req)
    def put(self, params):
        """
            修改
        """
        return {'partnumber_item': partnumber_item_service.update_partnumber_item(params)}


    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(base_resource_fields)
    @pre.catch(PartnumberItemDTO.delete_partnumber_item_req)
    def delete(self, params):
        """
            刪除
        """
        partnumber_item_service.delete_partnumber_item(params.get("id"))
        return delete_success_resp


@api.route('/list')
class PartnumberItemList(customResource):
    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(PartnumberItemDTO.partnumber_list_resp_fields_model)
    @pre.catch(get=PartnumberItemDTO.get_partnumber_item_list_req)
    def get(self, params):
        """
            獲取
        """
        _partnumber_item_type_list = partnumber_item_service._get_partnumber_item_type_list_by_params(params)
        if _partnumber_item_type_list and len(_partnumber_item_type_list) > 0:
            _partnumber_item_type_id_list = [_partnumber_item_type.id for _partnumber_item_type in
                                             _partnumber_item_type_list]
            params['item_type_id'] = _partnumber_item_type_id_list
            return {'partnumber_item_list': partnumber_item_service.get_partnumber_item_list_by_params(params)}
        return {'partnumber_item_list': []}
        # return {'partnumber_item_list': partnumber_item_service.get_partnumber_item_list_by_params(params)}