from app.dto.asset_dto import AssetDTO
from app.service import asset_service
from app.service import partnumber_service
from app.util.Api_base_resource import customResource
from app.util.OAuthClient import require_oauth
from app.util.pre_request import pre

api = AssetDTO.api


@api.route('/consumable/page')
class AssetConsumablePage(customResource):
    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(AssetDTO.asset_consumable_pagination_resp_fields_model)
    @pre.catch(get=AssetDTO.get_asset_consumable_paginate_by_item_params_req)
    def get(self, params):
        """
            獲取資產耗材分頁列表
        """
        params['partnumber_id'] = [_pn.id for _pn in partnumber_service.get_partnumber_list_by_params(params)]
        return asset_service.get_asset_consumable_page_by_params(params, page_index=params['page_index'],
                                                                 per_page=params['per_page'])


@api.route('/equipment/page')
class AssetEquipmentPage(customResource):
    @require_oauth('server')
    # @require_role(contains_any=enum_role.get_name_list())
    @api.marshal_with(AssetDTO.asset_equipment_pagination_resp_fields_model)
    @pre.catch(get=AssetDTO.get_asset_equipment_paginate_by_item_params_req)
    def get(self, params):
        """
            獲取資產設備分頁列表
        """
        params['partnumber_id'] = [_pn.id for _pn in partnumber_service.get_partnumber_list_by_params(params)]
        return asset_service.get_asset_equipment_page_by_params(params, page_index=params['page_index'],
                                                                per_page=params['per_page'])


@api.route('/consumable/file')
class AssetConsumableFile(customResource):

    @require_oauth('server')
    @api.marshal_with(AssetDTO.file_resp_fields_model)
    @pre.catch(AssetDTO.post_asset_file_params_req)
    def post(self, params):
        """
            上传资产耗材文件
        """
        return asset_service.update_asset_consumable_by_file(params['file'])


@api.route('/equipment/file')
class AssetEquipmentFile(customResource):

    @require_oauth('server')
    @api.marshal_with(AssetDTO.file_resp_fields_model)
    @pre.catch(AssetDTO.post_asset_file_params_req)
    def post(self, params):
        """
            上传资产设备文件
        """

        return asset_service.update_asset_equipment_by_file(params['file'])
