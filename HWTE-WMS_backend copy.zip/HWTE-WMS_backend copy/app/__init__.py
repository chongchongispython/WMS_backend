# !/usr/bin/env python3
# -*- coding: UTF-8 -*-
import os
import traceback
from typing import Optional, Callable

from authlib.integrations.flask_client import OAuth
from authlib.integrations.flask_oauth2 import current_token
from flask import Flask, g, request
from werkzeug.http import HTTP_STATUS_CODES

from app.config import read_config
# 创建 app
from app.model import db, db_mongo
from app.model.system_log import system_log
from app.util.Api_exceptions import InvalidRequestError
from app.util.pre_request import BaseResponse, ParamsValueError, pre

app = Flask(__name__)

oauth = OAuth(app)
pre.init_app(app=app)


class CustomResponse(BaseResponse):

    def make_response(
            cls,
            error: "ParamsValueError",
            fuzzy: bool = False,
            formatter: Optional[Callable] = None
    ):
        raise InvalidRequestError(msg=getattr(cls, "message", HTTP_STATUS_CODES.get(400, '')))


# class CustomFilter(BaseFilter):
#
#     def filter_required(self):
#         """ 检查当前过滤式，是否必须要执行
#         """
#         return True
#
#     def __call__(self, *args, **kwargs):
#         """ 自定义过滤器时需要实现的主要功能
#         """
#         super().__call__()
#
#         if self.rule.direct_type == int and self.key == "number" and self.value != 10086:
#             raise ParamsValueError(message="any error messages you want")
#
#         return self.value + 1

pre.add_response(CustomResponse)


# 创建 db

def init_oauth():
    oauth.register(
        name='myserver',
        client_id=app.config.get("MYSERVER_CLIENT_ID"),
        client_secret=app.config.get("MYSERVER_CLIENT_SECRET"),
        api_base_url=app.config.get("MYSERVER_BASE_URL"),
        access_token_url=app.config.get("MYSERVER_ACCESS_TOKEN_URL"),
        client_kwargs={
            # 'grant_type': 'password',
            'scope': 'server',
            'token_endpoint_auth_method': 'client_secret_basic',
        }
    )


def create_app(env):
    # 读取环境变量
    app.config.from_object(read_config(env))
    # 注册 db
    db_mongo.init_app(app)
    db.init_app(app)
    init_oauth()
    return app


@app.before_first_request
def app_first_request():
    db.create_all()
    db.session.commit()


@app.after_request
def app_after_request(response):
    # print(g.api_func_desc)
    # print(g.api_desc)
    ISLOGGING = eval(os.getenv('IS_LOGGING') or "True")
    # for query in get_debug_queries():
    #     # query.statement：查询的sql
    #     # query.duration： 耗时
    #     # 打印超时sql和时间
    #     if query.duration > 0.01:
    #         print('----慢sql-----\t\nsql:\t\n {sql} \n\t耗时:{duration}'.format(sql=query.statement, duration=query.duration))

    try:
        if not request.method == "OPTIONS" and \
                request.path.find("static").__eq__(-1) and \
                ISLOGGING:

            new_system_log = system_log()
            new_system_log.request_url = request.path
            new_system_log.request_method = request.method
            new_system_log.request_api_desc = g.api_func_desc
            new_system_log.request_api_module_desc = g.api_desc
            new_system_log.request_datas = {"headers": request.headers, "form": request.form, "args": request.args,
                                            "json": request.json if request.is_json else {}, "files": str(request.files.to_dict())}
            res_json = response.get_json()
            _code = res_json.get('code') if res_json else None
            _msg = res_json.get('msg') if res_json else None
            new_system_log.response_datas['code'] = _code
            new_system_log.response_datas['msg'] = _msg

            if current_token:
                new_system_log.user_name = current_token.get('username')
                new_system_log.user_employee_id = current_token.get('aud')

            elif g.api_func_desc == "login":
                req_json = request.json
                new_system_log.user_name = "Unknow"
                new_system_log.user_employee_id = req_json.get("username")
                new_system_log.request_datas = {"headers": request.headers, "form": request.form, "args": request.args,
                                                "json": {}, "files": str(request.files.to_dict())}
            else:
                new_system_log.user_name = "Unknow"
                new_system_log.user_employee_id = "Unknow"

            new_system_log.save()
    except:
        traceback.print_exc()
    finally:
        return response
