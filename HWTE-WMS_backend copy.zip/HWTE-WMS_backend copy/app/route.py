# !/usr/bin/env python3
# -*- coding: UTF-8 -*-
from logging.config import dictConfig

from flask import Blueprint

from app.config.base_config import api_config
from app.controller import *
# 创建蓝图
from app.util.Api_extend import ExtendedAPI

blueprint = Blueprint('api', __name__, url_prefix='/wms_api')
# 创建 REST API
api = ExtendedAPI(blueprint, **api_config)

# 注册路由
api.add_namespace(asset, path='/asset')
api.add_namespace(partnumber, path='/partnumber')
api.add_namespace(public_menu, path='/public_menu')
api.add_namespace(partnumber_item, path='/partnumber_item')
api.add_namespace(phase, path='/phase')
api.add_namespace(product, path='/product')


dictConfig({
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {  # 日志输出样式
        "default": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        }
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",  # 控制台输出
            "level": "DEBUG",
            "formatter": "default",
        },
        "log_file": {
            "class": "logging.handlers.RotatingFileHandler",
            "level": "INFO",
            "formatter": "default",  # 日志输出样式对应formatters
            "filename": "flask.log",  # 指定log文件目录
            "maxBytes": 20 * 1024 * 1024,  # 文件最大20M
            "backupCount": 10,  # 最多10个文件
            "encoding": "utf8",  # 文件编码
        },

    },
    "root": {
        "level": "INFO",  # # handler中的level会覆盖掉这里的level
        "handlers": ["console", "log_file"],
    },
}
)
