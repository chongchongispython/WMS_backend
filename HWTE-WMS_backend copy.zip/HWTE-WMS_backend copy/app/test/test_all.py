import unittest

import unittestreport

# 1、加载测试用例到套件中
from app.lib.datetimeLib import dt

suite = unittest.defaultTestLoader.discover('./test_cases')

# 2、创建一个用例运行程序
runner = unittestreport.TestRunner(suite,
                                   tester='athur',
                                   filename='test_report_{}'.format(dt.datetime),
                                   report_dir="./report",
                                   title='HWTE倉儲系統測試報告',
                                   desc='全部用例',
                                   templates=3)

# 3、运行测试用例
# thread_count=5
runner.run()
