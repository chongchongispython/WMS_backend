import os.path

import requests
from app.service import phase_service
from app.test.test_cases import BaseTestCase

class TestPhase(BaseTestCase):

    def test_positive_add_phase(self):
        """
        测试正向添加階段
        Returns:

        """
        params = {
        }
        positive_add = phase_service.add_phase(params)
        self.assertEqual(positive_add.version_name, params['version_name'])