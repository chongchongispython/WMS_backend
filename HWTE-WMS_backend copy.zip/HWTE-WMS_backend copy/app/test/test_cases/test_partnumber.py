#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import os.path

import requests
from sqlalchemy import func

from app.model.partnumber_model import Partnumber
from app.test.test_cases import BaseTestCase
from app.util.Api_exceptions import NotFoundError

ASSERT_MSG = "msg: {}\nreq_params: {}\nraw result: {}"


class TestPartnumber(BaseTestCase):

    def test_positive_get_partnumber_list(self):
        """
            test get partnumber list
        """
        rst = requests.get(os.path.join(self.host, "partnumber/page"), headers=self.headers, params=self.get_partnumbers_by_params_req)
        rst.raise_for_status()
        rst = rst.json()
        self.assertEqual(rst['code'], 200, msg=ASSERT_MSG.format(rst['msg'], self.get_partnumbers_by_params_req, rst))

    def add_partnumber(self):
        add_partnumber_list = []
        for add_partnumbers_by_params_req in self.positive_add_partnumbers_by_params_req_list:
            rst = requests.post(os.path.join(self.host, "partnumber"), headers=self.headers, params=add_partnumbers_by_params_req)
            rst.raise_for_status()
            rst = rst.json()
            self.assertEqual(rst['code'], 200, msg=ASSERT_MSG.format(rst['msg'], add_partnumbers_by_params_req, rst))
            add_partnumber_list.append({
                "partnumber_id": rst['result']['partnumber_id']
            })
        return add_partnumber_list

    def test_positive_add_partnumber(self):
        """
            test 10 times to add partnumber
        """
        self.add_partnumber()

    def test_negative_add_partnumber(self):
        """
            test 10 times negative add partnumber
            test partnumber model @validates method
        """
        for add_partnumbers_by_params_req in self.negative_add_partnumbers_by_params_req_list:
            rst = requests.post(os.path.join(self.host, "partnumber"), headers=self.headers, params=add_partnumbers_by_params_req)
            rst.raise_for_status()
            rst = rst.json()
            self.assertEqual(rst['code'], 406, msg=ASSERT_MSG.format(rst['msg'], add_partnumbers_by_params_req, rst))

    def test_positive_update_partnumber(self):
        """
            test 10 times to update partnumber
        """
        for update_partnumbers_by_params_req in self.positive_update_partnumbers_by_params_req_list:
            rst = requests.put(os.path.join(self.host, "partnumber"), headers=self.headers, json=update_partnumbers_by_params_req)
            rst.raise_for_status()
            rst = rst.json()
            self.assertEqual(rst['code'], 200, msg=ASSERT_MSG.format(rst['msg'], update_partnumbers_by_params_req, rst))

    def test_negative_update_partnumber(self):
        """
            test update partnumber 404 not found
        """
        params = {
            "partnumber_id": 9999999999,
            "price": self.fake.random.choice((self.fake.pricetag(), None)),
            "currency": self.fake.random.choice((self.fake.cryptocurrency_code(), None)),
        }
        rst = requests.put(os.path.join(self.host, "partnumber"), headers=self.headers, json=params)
        rst.raise_for_status()
        rst = rst.json()
        self.assertEqual(rst['code'], 404, msg=ASSERT_MSG.format(rst['msg'], params, rst))

    def test_positive_delete_partnumber(self):
        """
            test 10 times to delete partnumber
        """
        self.positive_delete_partnumbers_by_params_req_list = self.add_partnumber()
        for positive_delete_partnumbers_by_params_req in self.positive_delete_partnumbers_by_params_req_list:
            rst = requests.delete(os.path.join(self.host, "partnumber"), headers=self.headers, json=positive_delete_partnumbers_by_params_req)
            rst.raise_for_status()
            rst = rst.json()
            self.assertEqual(rst['code'], 200, msg=ASSERT_MSG.format(rst['msg'], positive_delete_partnumbers_by_params_req, rst))

    def test_negative_delete_partnumber(self):
        """
            test delete partnumber 404 not found
        """
        params = {
            "partnumber_id": 9999999999,
            "price": self.fake.random.choice((self.fake.pricetag(), None)),
            "currency": self.fake.random.choice((self.fake.cryptocurrency_code(), None)),
        }
        rst = requests.delete(os.path.join(self.host, "partnumber"), headers=self.headers, json=params)
        rst.raise_for_status()
        rst = rst.json()
        self.assertEqual(rst['code'], 404, msg=ASSERT_MSG.format(rst['msg'], params, rst))

    def test_positive_binding_partnumber(self):
        """
            test rebind partnumber
        """
        partnumber_id = Partnumber._get_model_sql_by_params().order_by(func.rand()).first().id
        real_partnumber_id = Partnumber._get_model_sql_by_params().filter(Partnumber.id != partnumber_id).order_by(func.rand()).first().id
        params = {
            "partnumber_id": partnumber_id,
            "real_partnumber_id": real_partnumber_id
        }

        rst = requests.put(os.path.join(self.host, "partnumber/binding"), headers=self.headers, json=params)
        rst.raise_for_status()
        rst = rst.json()
        self.assertEqual(rst['code'], 200, msg=ASSERT_MSG.format(rst['msg'], params, rst))
        self.assertRaises(Partnumber.get_model_by_id(partnumber_id), NotFoundError)