#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import multiprocessing
import os

from faker import Faker
from flask import _app_ctx_stack
from flask_testing import LiveServerTestCase
from sqlalchemy import func, text

from app import create_app, db
from app.model.partnumber_item_model import PartnumberItem
from app.model.partnumber_item_type_model import PartnumberItemType
from app.model.partnumber_model import Partnumber
from app.model.public_menu_model import PublicMenu
from app.route import blueprint
from project_root_path import root_dir

multiprocessing.set_start_method("fork")
os.environ['OBJC_DISABLE_INITIALIZE_FORK_SAFETY'] = 'YES'

# from gevent import monkey
# monkey.patch_all()

app = create_app('test')
app.register_blueprint(blueprint)
app.config['LIVESERVER_PORT'] = 62253


class BaseTestCase(LiveServerTestCase):
    """ Base Tests """

    def create_app(self):
        return app

    def setUp(self):
        self.fake = Faker()
        self.InitDB()
        self.InitPartnumberData()
        self.InitPublicMenuData()

    def tearDown(self):
        db.session.remove()

    @property
    def host(self):
        return "{}/wms_api".format(self.get_server_url())

    @property
    def headers(self):
        return {"Authorization": "Bearer jTUSOHY9nkK7uNeQzvUdhFml7Q1RgAOEXI4IrfjbaX"}

    def InitDB(self):
        self.__excuteSQLFile(os.path.join(root_dir, 'hwte_wms_test.sql'))

    def DropDB(self):
        self.__excuteSQLFile(os.path.join(root_dir, 'hwte_wms_test_drop.sql'))

    def __excuteSQLFile(self, file_path):
        sql_file = open(file_path, 'r')

        # Create an empty command string
        sql_command = ''

        # Iterate over all lines in the sql file
        for line in sql_file:
            # Ignore commented lines
            if not line.startswith('--') and line.strip('\n'):
                # Append line to the command string
                sql_command += line.strip('\n')

                # If the command string ends with ';', it is a full statement
                if sql_command.endswith(';'):
                    # Try to execute statement and commit it
                    try:
                        db.session.execute(text(sql_command))
                        db.session.commit()

                    # Assert in case of error
                    except:
                        print('Ops')

                    # Finally, clear command string
                    finally:
                        sql_command = ''
        sql_file.close()

    def InitToken(self):
        setattr(_app_ctx_stack.top, "authlib_server_oauth2_token",
                {'access_token': f'test', 'active': True, 'aud': 'F1238262', 'client_id': 'Lc1Iz0ta2LNyaAvFycw8zLeB', 'exp': 864000, 'iat': 1663663076, 'iss': 'https://server.example.com/', 'scope': 'server', 'token_type': 'Bearer', 'username': 'athur'})

    def InitPartnumberData(self):
        self.type_asset_category = PartnumberItemType.get_model_by_params({"type_name": "asset_category"})
        self.type_standard_name = PartnumberItemType.get_model_by_params({"type_name": "standard_name"})
        self.type_spec = PartnumberItemType.get_model_by_params({"type_name": "spec"})
        self.type_vendor = PartnumberItemType.get_model_by_params({"type_name": "vendor"})
        self.type_station = PartnumberItemType.get_model_by_params({"type_name": "station"})

        self._InitGetPartnumberListParams()

    def _InitGetPartnumberListParams(self):
        self.get_partnumbers_by_params_req = {}
        self.positive_add_partnumbers_by_params_req_list = []
        self.negative_add_partnumbers_by_params_req_list = []
        self.positive_update_partnumbers_by_params_req_list = []
        self.positive_delete_partnumbers_by_params_req_list = []

        Faker.seed(0)
        for i in range(10):
            random_asset_category_id = PartnumberItem._get_model_sql_by_params({"item_type_id": self.type_asset_category.id}).order_by(func.rand()).first().id
            random_standard_name_id = PartnumberItem._get_model_sql_by_params({"item_type_id": self.type_standard_name.id}).order_by(func.rand()).first().id
            random_spec_id = PartnumberItem._get_model_sql_by_params({"item_type_id": self.type_spec.id}).order_by(func.rand()).first().id
            random_vendor_id = PartnumberItem._get_model_sql_by_params({"item_type_id": self.type_vendor.id}).order_by(func.rand()).first().id
            random_station_id = PartnumberItem._get_model_sql_by_params({"item_type_id": self.type_station.id}).order_by(func.rand()).first().id
            random_partnumber_id = Partnumber._get_model_sql_by_params().order_by(func.rand()).first().id

            self.get_partnumbers_by_params_req = {
                "asset_category_id": self.fake.random.choice((random_asset_category_id, None)),
                "standard_name_id": self.fake.random.choice((random_standard_name_id, None)),
                "spec_id": self.fake.random.choice((random_spec_id, None)),
                "vendor_id": self.fake.random.choice((random_vendor_id, None)),
                "station_id": self.fake.random.choice((random_station_id, None)),
                "is_virtual": self.fake.random.choice((self.fake.pybool(), None)),
                "page_index": 1,
                "per_page": 20
            }

            self.positive_add_partnumbers_by_params_req_list.append({
                "asset_category_id": random_asset_category_id,
                "standard_name_id": random_standard_name_id,
                "spec_id": random_spec_id,
                "vendor_id": random_vendor_id,
                "station_id": random_station_id,
                "price": self.fake.pricetag(),
                "currency": self.fake.cryptocurrency_code(),
            })

            # test model @validates
            self.negative_add_partnumbers_by_params_req_list.append({
                "asset_category_id": self.fake.random.choice((random_asset_category_id, random_standard_name_id, random_spec_id, random_vendor_id, random_station_id)),
                "standard_name_id": self.fake.random.choice((random_asset_category_id, random_standard_name_id, random_spec_id, random_vendor_id, random_station_id)),
                "spec_id": self.fake.random.choice((random_asset_category_id, random_standard_name_id, random_spec_id, random_vendor_id, random_station_id)),
                "vendor_id": self.fake.random.choice((random_asset_category_id, random_standard_name_id, random_spec_id, random_vendor_id, random_station_id)),
                "station_id": self.fake.random.choice((random_asset_category_id, random_standard_name_id, random_spec_id, random_vendor_id)),
                "price": self.fake.pricetag(),
                "currency": self.fake.cryptocurrency_code(),
            })

            self.positive_update_partnumbers_by_params_req_list.append({
                "partnumber_id": random_partnumber_id,
                "price": self.fake.random.choice((self.fake.pricetag(), None)),
                "currency": self.fake.random.choice((self.fake.cryptocurrency_code(), None)),
            })

    def InitPublicMenuData(self):
        self.get_public_menus_by_params_req_list = [
            {
                "menu_name": self.fake.pystr(),
                "depth": 1
            }, {
                "menu_name": self.fake.pystr(),
                "depth": 2
            }, {
                "menu_name": self.fake.pystr(),
                "depth": 3
            },
        ]

        self.add_public_menu_by_params_req = [
            {
                "menu_name": self.fake.pystr(),
                "parent_id": None,
                "menu_config": None,
                "is_updatable": True,
            }, {
                "menu_name": self.fake.pystr(),
                "parent_id": None,
                "menu_config": None,
                "is_updatable": False,
            }, {
                "menu_name": self.fake.pystr(),
                "parent_id": None,
                "menu_config": {},
                "is_updatable": True,
            },
        ]

        self.update_public_menu_by_params_req = [
            {
                "menu_id": PublicMenu._get_model_sql_by_params().order_by(func.rand()).first().id,
                "menu_name": self.fake.pystr(),
                "parent_id": None,
                "menu_config": {},
                "is_updatable": True,
            }, {
                "menu_id": PublicMenu._get_model_sql_by_params().order_by(func.rand()).first().id,
                "menu_name": self.fake.pystr(),
                "parent_id": None,
                "menu_config": {},
                "is_updatable": False,
            }, {
                "menu_id": PublicMenu._get_model_sql_by_params().order_by(func.rand()).first().id,
                "menu_name": self.fake.pystr(),
                "parent_id": None,
                "menu_config": {},
                "is_updatable": True,
            }, {
                "menu_id": PublicMenu._get_model_sql_by_params().order_by(func.rand()).first().id,
                "menu_name": self.fake.pystr(),
                "parent_id": None,
                "menu_config": None,
                "is_updatable": True,
            },
        ]

        self.delete_public_menu_by_params_req = [
            {
                "menu_id": PublicMenu._get_model_sql_by_params().order_by(func.rand()).first().id,
            }
        ]
