#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import os.path

import requests

from app.test.test_cases import BaseTestCase

ASSERT_MSG = "msg: {}\nreq_params: {}\nraw result: {}"


class TestPublicMenu(BaseTestCase):

    def test_positive_get_public_menu_list(self):
        """
            test get public menu list
        """
        for _data in self.get_public_menus_by_params_req_list:
            rst = requests.get(os.path.join(self.host, "public_menu/list"), headers=self.headers, params=_data)
            rst.raise_for_status()
            rst = rst.json()
            self.assertEqual(rst['code'], 200, msg=ASSERT_MSG.format(rst['msg'], _data, rst))

    def test_positive_add_public_menu(self):
        """
            test add public menu
        """
        for _data in self.add_public_menu_by_params_req:
            rst = requests.post(os.path.join(self.host, "public_menu"), headers=self.headers, json=_data)
            rst.raise_for_status()
            rst = rst.json()
            self.assertEqual(rst['code'], 200, msg=ASSERT_MSG.format(rst['msg'], _data, rst))

    def test_positive_update_public_menu(self):
        """
            test update public menu
        """
        for _data in self.update_public_menu_by_params_req:
            rst = requests.put(os.path.join(self.host, "public_menu"), headers=self.headers, json=_data)
            rst.raise_for_status()
            rst = rst.json()
            self.assertEqual(rst['code'], 200, msg=ASSERT_MSG.format(rst['msg'], _data, rst))


    def test_positive_delete_public_menu(self):
        """
            test update public menu
        """
        for _data in self.delete_public_menu_by_params_req:
            rst = requests.delete(os.path.join(self.host, "public_menu"), headers=self.headers, json=_data)
            rst.raise_for_status()
            rst = rst.json()
            self.assertEqual(rst['code'], 200, msg=ASSERT_MSG.format(rst['msg'], _data, rst))