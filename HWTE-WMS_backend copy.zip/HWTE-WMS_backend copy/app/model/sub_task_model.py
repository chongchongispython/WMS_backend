from sqlalchemy import UniqueConstraint

from app import db
from app.model import createAndUpdateMixin, base_model
from app.model.sub_task_participant_model import SubTaskParticipant
from app.util.enums import enum_task_type, enum_group_type, enum_sub_task_type, enum_participant_type


class SubTask(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_sub_task'
    __table_args__ = (
        UniqueConstraint("main_task_id", "task_name", "branch_type", "branch_group"),
        UniqueConstraint("main_task_id", "task_name", "branch_type", "branch_group"),
    )

    id = db.Column(db.Integer, primary_key=True)
    main_task_id = db.Column(db.ForeignKey("wms_main_task.id"), nullable=False)
    task_name = db.Column(db.String(64), nullable=False)
    branch_type = db.Column(db.Enum(enum_group_type), nullable=False)
    branch_group = db.Column(db.String(64), nullable=False)
    status = db.Column(db.Enum(enum_sub_task_type), nullable=False)
    start_time = db.Column(db.TIMESTAMP, nullable=False)
    end_time = db.Column(db.TIMESTAMP, nullable=False)

    _participant = db.relationship("ConnectSubTaskEmpID", lazy="dynamic")
    _main_task = db.relationship("MainTask")
    _reply_targets = db.relationship("")

    def get_participant_by_type(self, participant_type: enum_participant_type):
        return self._participant.filter(SubTaskParticipant.assign_type == participant_type.value).all()

