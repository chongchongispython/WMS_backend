from app import db

from app.model import createAndUpdateMixin, base_model


class Product(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_product'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    fx_code = db.Column(db.String(64), unique=True, nullable=False)

    _phases = db.relationship("Phase", order_by="Phase.start_time", cascade="all,delete")

