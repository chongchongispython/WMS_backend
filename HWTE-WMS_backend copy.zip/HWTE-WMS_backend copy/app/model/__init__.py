import collections
import json
import re

from authlib.integrations.flask_oauth2 import current_token
from flask import current_app
from flask_mongoengine import MongoEngine
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.mysql import insert

from app.util.Api_exceptions import NotFoundError
from app.util.pre_request.utils import _Missing

db = SQLAlchemy()
db_mongo = MongoEngine()


class createAndUpdateMixin(object):
    creator_account = db.Column(db.String(15), nullable=False)
    updater_account = db.Column(db.String(15), nullable=False)
    creator_name = db.Column(db.String(15), nullable=False)
    updater_name = db.Column(db.String(15), nullable=False)
    create_time = db.Column(db.TIMESTAMP, nullable=False, server_default=db.text('CURRENT_TIMESTAMP'))
    last_update_time = db.Column(db.TIMESTAMP, nullable=False, server_default=db.text(
        'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'))  # 时间戳，不为空，更新时间，默认为当前时间


class base_model(object):

    @classmethod
    def insert_or_update(model, insert_dict, ignore_update=[]):
        """model can be a db.Model or a table(), insert_dict should contain a primary or unique key."""
        if "creator_account" in model._get_colomns():
            insert_dict["creator_account"] = current_token.get("aud")
            insert_dict["creator_name"] = current_token.get("username")
            insert_dict["updater_account"] = current_token.get("aud")
            insert_dict["updater_name"] = current_token.get("username")

        inserted = insert(model).values(**insert_dict)
        upserted = inserted.on_duplicate_key_update(**{k: inserted.inserted[k]
                                                       for k, v in insert_dict.items() if k not in ignore_update})
        res = db.session.execute(upserted)
        return res.lastrowid

    def to_dict(self, show=None, hide=None, path=None, show_all=None):
        """ Return a dictionary representation of this model.
        """

        if not show:
            show = []
        if not hide:
            hide = []
        hidden = []
        if hasattr(self, 'hidden_fields'):
            hidden = self.hidden_fields
        default = []
        if hasattr(self, 'default_fields'):
            default = self.default_fields

        ret_data = {}

        if not path:
            path = self.__tablename__.lower()

            def prepend_path(item):
                item = item.lower()
                if item.split('.', 1)[0] == path:
                    return item
                if len(item) == 0:
                    return item
                if item[0] != '.':
                    item = '.%s' % item
                item = '%s%s' % (path, item)
                return item

            show[:] = [prepend_path(x) for x in show]
            hide[:] = [prepend_path(x) for x in hide]

        columns = self.__table__.columns.keys()
        relationships = self.__mapper__.relationships.keys()
        properties = dir(self)

        for key in columns:
            check = '%s.%s' % (path, key)
            if check in hide or key in hidden:
                continue
            if show_all or key is 'id' or check in show or key in default:
                ret_data[key] = getattr(self, key)

        for key in relationships:
            check = '%s.%s' % (path, key)
            if check in hide or key in hidden:
                continue
            if show_all or check in show or key in default:
                hide.append(check)
                is_list = self.__mapper__.relationships[key].uselist
                if is_list:
                    ret_data[key] = []
                    for item in getattr(self, key):
                        ret_data[key].append(item.to_dict(
                            show=show,
                            hide=hide,
                            path=('%s.%s' % (path, key.lower())),
                            show_all=show_all,
                        ))
                else:
                    if self.__mapper__.relationships[key].query_class is not None:
                        ret_data[key] = getattr(self, key).to_dict(
                            show=show,
                            hide=hide,
                            path=('%s.%s' % (path, key.lower())),
                            show_all=show_all,
                        )
                    else:
                        ret_data[key] = getattr(self, key)

        for key in list(set(properties) - set(columns) - set(relationships)):
            if key.startswith('_'):
                continue
            check = '%s.%s' % (path, key)
            if check in hide or key in hidden:
                continue
            if show_all or check in show or key in default:
                val = getattr(self, key)
                try:
                    ret_data[key] = json.loads(json.dumps(val))
                except:
                    pass

        return ret_data

    def set_createAndUpdateMixin(self, is_create=True, is_update=True):
        if is_create:
            self.creator_account = current_token.get("aud")
            self.creator_name = current_token.get("username")

        if is_update:
            self.updater_account = current_token.get("aud")
            self.updater_name = current_token.get("username")

    @classmethod
    def _get_colomns(cls):
        return cls.__table__.columns.keys()

    @classmethod
    def _get_relationships(cls):
        return cls.__mapper__.relationships.keys()

    @classmethod
    def add_model_by_params(cls, params: dict, ignores=[]):
        """

        Args:
            params: model columns params
            transfer: convert params`s keys : params :{"user_name":"athur"} transfer :{"user_name":"name"}

        Returns: model

        """
        new_cls = cls()
        for k in params.keys():
            if k in ignores:
                continue
            elif k not in dir(cls):
                current_app.logger.warning("{} not found in model {}".format(k, cls.__name__))
                continue
            else:
                setattr(new_cls, k, params.get(k))

        if "creator_account" in cls._get_colomns():
            new_cls.set_createAndUpdateMixin()

        db.session.add(new_cls)
        return new_cls

    def update_model_by_params(self, params: dict, ignores=[]):
        """

        Args:
            params: model columns params
            transfer: convert params`s keys : params :{"user_name":"athur"} transfer :{"user_name":"name"}

        Returns: model

        """

        for k, v in params.items():
            if k in ignores:
                continue
            elif v is _Missing:
                continue
            elif k not in dir(self):
                current_app.logger.warning("{} not found in model {}".format(k, self.__class__.__name__))
                continue
            else:
                setattr(self, k, v)

        if "creator_account" in self._get_colomns():
            self.set_createAndUpdateMixin(is_create=False)

        return self

    @classmethod
    def get_model_by_id(cls, id, check=True):
        """

        Args:
            id: model`s id or primary key

        Returns: model

        """
        _cls = cls.query.get(id)
        if not _cls and check:
            raise NotFoundError(msg=f"{cls.__name__} id {id} not found")
        return _cls

    @classmethod
    def get_model_by_params(cls, params, ignores=[], orders=collections.OrderedDict(), check=True):
        """

        Args:


        Returns: model

        """
        _cls = cls._get_model_sql_by_params(params, ignores, orders).one_or_none()
        if not _cls and check:
            raise NotFoundError(msg=f"{cls.__name__} not found")
        return _cls

    @classmethod
    def get_model_list_by_params(cls, params={}, ignores=[], skip_none=True, orders=collections.OrderedDict()):
        """
        Args:
            params: model columns params
            transfer: convert params`s keys : params :{"user_name":"athur"} transfer :{"user_name":"name"}
            orders: dictionary of order_by

        """
        return cls._get_model_sql_by_params(params=params, ignores=ignores, orders=orders, skip_none=skip_none).all()

    @classmethod
    def get_model_list_by_params_paginate(cls, params={}, page_index=1, per_page=20, ignores=[], skip_none=True,
                                          orders=collections.OrderedDict()):
        """
        Args:
            params: model columns params
            page: current page
            page_count: page number
            transfer: convert params`s keys : params :{"user_name":"athur"} transfer :{"user_name":"name"}
            orders: dictionary of order_by

        """
        return cls._get_model_sql_by_params(params=params, ignores=ignores, orders=orders, skip_none=skip_none).paginate(page=page_index, per_page=per_page)

    @classmethod
    def _get_model_sql_by_params(cls, params={}, ignores=[], skip_none=True, orders=collections.OrderedDict()):
        """

        Args:
            params: model columns params
            transfer: convert params`s keys : params :{"user_name":"athur"} transfer :{"user_name":"name"}
            orders: dictionary of order_by

        Returns:

        """
        common_filters = []
        for k in params.keys():

            if k in ignores:
                continue

            elif (params.get(k) is None and skip_none) or params.get(k) is _Missing:
                continue

            elif k not in dir(cls):
                current_app.logger.warning("{} not found in model {}".format(k, cls.__name__))
                continue

            val = params.get(k)
            if isinstance(val, str):
                # fuzzy search
                if re.match(".*\%.*\%.*", val):
                    common_filters.append(eval(f"cls.{k}.like('{val}')"))
                else:
                    common_filters.append(eval(f"cls.{k}=='{val}'"))
            elif isinstance(val, list):
                common_filters.append(eval(f"cls.{k}.in_({val})"))
            elif isinstance(val, bool):
                common_filters.append(eval(f"cls.{k}=={val}"))
            elif val == None:
                common_filters.append(eval(f"cls.{k}=={val}"))
            else:
                common_filters.append(eval(f"cls.{k}=='{val}'"))

        # order_list=[getattr(cls, f"{k}.{v}()") for k,v in orders.items()]

        return cls.query \
            .filter(*common_filters) \
            .order_by(*[getattr(getattr(cls, k), v)() for k, v in orders.items()])

    @classmethod
    def delete_model_by_id(cls, id):
        """

        Args:
            id: model`s id or primary key

        Returns: None

        """
        db.session.delete(cls.get_model_by_id(id))
