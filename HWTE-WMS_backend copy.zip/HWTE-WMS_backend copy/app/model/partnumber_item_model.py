from sqlalchemy import UniqueConstraint

from app import db
from app.model import createAndUpdateMixin, base_model


class PartnumberItem(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_partnumber_item'
    __table_args__ = (
        UniqueConstraint("item_type_id", "item_code", "parent_id", "is_virtual"),
    )

    id = db.Column(db.Integer, primary_key=True)
    item_name = db.Column(db.String(128), nullable=False, unique=True)
    item_type_id = db.Column(db.ForeignKey("wms_partnumber_item_type.id"), nullable=False)
    item_code = db.Column(db.Integer, nullable=False)
    parent_id = db.Column(db.ForeignKey("wms_partnumber_item.id"))
    is_virtual = db.Column(db.Boolean, nullable=False)

    _partnumber_item_type = db.relationship("PartnumberItemType")

    # def __init__(self, init_all_kwargs=False, **kwargs):
    #     self.item_name = kwargs.get("item_name")
    #     self.item_type_id = kwargs.get("item_type_id")
    #     self.item_code = kwargs.get("item_code")
    #     self.parent_id = kwargs.get("parent_id", None)
    #     self.is_virtual = kwargs.get("is_virtual")
    #
    #     if init_all_kwargs:
    #         for k in kwargs.keys():
    #             setattr(self, k, kwargs.get(k))