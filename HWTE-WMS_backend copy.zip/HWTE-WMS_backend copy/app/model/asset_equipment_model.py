from sqlalchemy import UniqueConstraint

from app import db

from app.model import createAndUpdateMixin, base_model


class AssetEquipment(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_asset_equipment'
    __table_args__ = (
        UniqueConstraint("partnumber_id", "total_qty", "asset_sn"),
    )

    id = db.Column(db.Integer, primary_key=True)
    partnumber_id = db.Column(db.ForeignKey("wms_partnumber.id"), nullable=False)
    total_qty = db.Column(db.Integer, nullable=False)
    department = db.Column(db.String(32), nullable=False)
    product = db.Column(db.String(32), nullable=False)
    build = db.Column(db.String(16), nullable=False)
    location = db.Column(db.String(64), nullable=False)
    usage_status = db.Column(db.String(8), nullable=False)
    asset_sn = db.Column(db.String(64), nullable=False)
    control_number = db.Column(db.String(32), nullable=False)
    property_number = db.Column(db.String(32), nullable=False)
    customs_number = db.Column(db.String(64), nullable=False)
    customs_filing_number = db.Column(db.String(16), nullable=False)
    rfid = db.Column(db.String(64), nullable=False)
    purchase_order = db.Column(db.String(32), nullable=False)
    remark = db.Column(db.String(255))

    _partnumber = db.relationship("Partnumber")
