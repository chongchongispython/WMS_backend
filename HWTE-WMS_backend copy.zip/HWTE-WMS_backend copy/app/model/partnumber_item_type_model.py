from app import db

from app.model import createAndUpdateMixin, base_model


class PartnumberItemType(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_partnumber_item_type'

    id = db.Column(db.Integer, primary_key=True)
    type_name = db.Column(db.String(32), nullable=False, unique=True)
    is_check = db.Column(db.Boolean, nullable=False)
    check_col_eq_name = db.Column(db.String(16), nullable=False)
    check_col_cs_name = db.Column(db.String(16), nullable=False)
    level = db.Column(db.Integer, nullable=False, unique=True)
    digit = db.Column(db.Integer, nullable=False)
    parent_id = db.Column(db.ForeignKey("wms_partnumber_item_type.id"))

    _partnumber_items = db.relationship("PartnumberItem", order_by="PartnumberItem.item_code")
