from sqlalchemy.orm import backref

from app import db
from app.model import createAndUpdateMixin, base_model


class PublicMenu(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_public_menu'

    id = db.Column(db.Integer, primary_key=True)
    menu_name = db.Column(db.String(32), nullable=False, unique=True)
    config = db.Column(db.String(255))
    parent_id = db.Column(db.ForeignKey("wms_public_menu.id"))
    is_updatable = db.Column(db.Boolean, nullable=False, default='1')

    _parent = db.relationship("PublicMenu", remote_side=[id], backref=backref("_children", cascade="all,delete"))
