from sqlalchemy import UniqueConstraint, or_, and_, select, func
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy.orm import aliased, validates

from app import db
from app.model import createAndUpdateMixin, base_model
from app.model.partnumber_item_model import PartnumberItem
from app.util.Api_exceptions import NotAcceptableError


class Partnumber(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_partnumber'
    __table_args__ = (
        UniqueConstraint("asset_category_item_id", "standard_name_item_id", "vendor_item_id", "station_item_id", "spec_item_id"),
    )

    id = db.Column(db.Integer, primary_key=True)
    asset_category_item_id = db.Column(db.ForeignKey("wms_partnumber_item.id"), nullable=False)
    standard_name_item_id = db.Column(db.ForeignKey("wms_partnumber_item.id"), nullable=False)
    vendor_item_id = db.Column(db.ForeignKey("wms_partnumber_item.id"), nullable=False)
    station_item_id = db.Column(db.ForeignKey("wms_partnumber_item.id"), nullable=False)
    spec_item_id = db.Column(db.ForeignKey("wms_partnumber_item.id"), nullable=False)
    zh_name = db.Column(db.String(64))
    en_name = db.Column(db.String(128))
    aqid = db.Column(db.String(16))
    vpn = db.Column(db.String(32))
    payment_method = db.Column(db.String(16))
    price = db.Column(db.String(16))
    currency = db.Column(db.String(16))
    fx_number = db.Column(db.String(64))
    is_enable = db.Column(db.Boolean, nullable=False, default=True)
    is_delete = db.Column(db.Boolean, nullable=False, default=False)
    remark = db.Column(db.String(255))

    _asset_category_item = db.relationship("PartnumberItem", foreign_keys=[asset_category_item_id])
    _standard_name_item = db.relationship("PartnumberItem", foreign_keys=[standard_name_item_id])
    _vendor_item = db.relationship("PartnumberItem", foreign_keys=[vendor_item_id])
    _station_item = db.relationship("PartnumberItem", foreign_keys=[station_item_id])
    _spec_item = db.relationship("PartnumberItem", foreign_keys=[spec_item_id])

    @hybrid_property
    def partnumber(self):
        return "{}{}{}{}{}".format(*[str(i.item_code).rjust(i._partnumber_item_type.digit, '0') for i in sorted([self._asset_category_item, self._standard_name_item, self._vendor_item, self._station_item, self._spec_item], key=lambda x: x._partnumber_item_type.level)])

    @partnumber.expression
    def partnumber(cls):
        return select([func.group_concat(PartnumberItem.item_code)]). \
            where(or_(PartnumberItem.id == cls.asset_category_item_id,
                      PartnumberItem.id == cls.standard_name_item_id,
                      PartnumberItem.id == cls.vendor_item_id,
                      PartnumberItem.id == cls.station_item_id,
                      PartnumberItem.id == cls.spec_item_id)) \
            .as_scalar()

    @hybrid_property
    def partnumber_items(self):
        return [self._asset_category_item, self._standard_name_item, self._vendor_item, self._station_item, self._spec_item]

    @hybrid_property
    def is_virtual(self):
        # return or_(self._asset_category_item.is_virtual, self._standard_name_item.is_virtual, self._vendor_item.is_virtual, self._station_item.is_virtual, self._spec_item.is_virtual)
        return self._asset_category_item.is_virtual or self._standard_name_item.is_virtual or self._vendor_item.is_virtual or self._station_item.is_virtual or self._spec_item.is_virtual

    @is_virtual.expression
    def is_virtual(cls):
        item1 = aliased(PartnumberItem)
        item2 = aliased(PartnumberItem)
        item3 = aliased(PartnumberItem)
        item4 = aliased(PartnumberItem)
        item5 = aliased(PartnumberItem)

        rst = db.session.query(Partnumber) \
            .join(item1, Partnumber.asset_category_item_id == item1.id) \
            .join(item2, Partnumber.standard_name_item_id == item2.id) \
            .join(item3, Partnumber.vendor_item_id == item3.id) \
            .join(item4, Partnumber.station_item_id == item4.id) \
            .join(item5, Partnumber.spec_item_id == item5.id) \
            .filter(or_(
            item1.is_virtual == True,
            item2.is_virtual == True,
            item3.is_virtual == True,
            item4.is_virtual == True,
            item5.is_virtual == True)).all()

        return cls.id.in_([i.id for i in rst])

    @validates('asset_category_item_id', 'standard_name_item_id', 'vendor_item_id', 'station_item_id', 'spec_item_id')
    def validate_name(self, key, value):

        if key == 'asset_category_item_id':
            if PartnumberItem.get_model_by_id(value)._partnumber_item_type.type_name != "asset_category": raise NotAcceptableError(msg="Invalid asset_category_item_id")
        elif key == 'standard_name_item_id':
            if PartnumberItem.get_model_by_id(value)._partnumber_item_type.type_name != "standard_name": raise NotAcceptableError(msg="Invalid standard_name_item_id")
        elif key == 'vendor_item_id':
            if PartnumberItem.get_model_by_id(value)._partnumber_item_type.type_name != "vendor": raise NotAcceptableError(msg="Invalid vendor_item_id")
        elif key == 'station_item_id':
            if PartnumberItem.get_model_by_id(value)._partnumber_item_type.type_name != "station": raise NotAcceptableError(msg="Invalid station_item_id")
        elif key == 'spec_item_id':
            if PartnumberItem.get_model_by_id(value)._partnumber_item_type.type_name != "spec": raise NotAcceptableError(msg="Invalid spec_item_id")
        else:
            raise

        return value
