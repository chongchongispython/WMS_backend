from sqlalchemy import UniqueConstraint

from app import db
from app.model import createAndUpdateMixin, base_model


class Phase(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_phase'
    __table_args__ = (
        UniqueConstraint("product_id", "name"),
    )
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.ForeignKey("wms_product.id", ondelete="CASCADE"), nullable=False)
    name = db.Column(db.String(64), nullable=False)
    start_time = db.Column(db.TIMESTAMP, nullable=False)
    end_time = db.Column(db.TIMESTAMP, nullable=False)

    _product = db.relationship("Product")
