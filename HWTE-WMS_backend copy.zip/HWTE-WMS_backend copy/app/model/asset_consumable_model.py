from sqlalchemy import UniqueConstraint

from app import db

from app.model import createAndUpdateMixin, base_model


class AssetConsumable(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_asset_consumable'
    __table_args__ = (
        UniqueConstraint("partnumber_id", "product"),
    )

    id = db.Column(db.Integer, primary_key=True)
    partnumber_id = db.Column(db.ForeignKey("wms_partnumber.id"), nullable=False)
    department = db.Column(db.String(32), nullable=False)
    product = db.Column(db.String(32), nullable=False)
    location = db.Column(db.String(64), nullable=False)
    total_qty = db.Column(db.Integer, nullable=False)
    non_defective_qty = db.Column(db.Integer, nullable=False)
    defective_qty = db.Column(db.Integer, nullable=False)
    remark = db.Column(db.String(255))

    _partnumber = db.relationship("Partnumber")
