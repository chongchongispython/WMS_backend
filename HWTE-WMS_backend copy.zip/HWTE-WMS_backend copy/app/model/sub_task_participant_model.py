from sqlalchemy import UniqueConstraint

from app import db
from app.model import createAndUpdateMixin, base_model
from app.util.enums import base_enum, enum_participant_type


class SubTaskParticipant(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_sub_task_replier'
    __table_args__ = (
        UniqueConstraint('sub_task_id', 'emp_id', 'assign_type'),
    )

    id = db.Column(db.Integer, primary_key=True)
    sub_task_id = db.Column(db.ForeignKey("wms_sub_task.id"), nullable=False)
    emp_id = db.Column(db.String(64), nullable=False)
    assign_type = db.Column(db.Enum(enum_participant_type), nullable=False)



