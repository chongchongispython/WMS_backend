import datetime
import json

from flask_mongoengine import Document

from app.model import db_mongo


class system_log(Document):
    uid = db_mongo.SequenceField(primary_key=True)  # 自增id
    user_name = db_mongo.StringField()
    user_employee_id = db_mongo.StringField()
    request_url = db_mongo.StringField()
    request_method = db_mongo.StringField()
    request_api_desc = db_mongo.StringField()
    request_api_module_desc = db_mongo.StringField()
    request_datas = db_mongo.DictField()
    response_datas = db_mongo.DictField()
    create_time = db_mongo.DateTimeField(default=datetime.datetime.now)

    meta = {
        "indexes": [
            {
                'fields': ['create_time'],
                'expireAfterSeconds': 3600 * 24 * 15
            }
        ]
    }

    def toDict(self):
        j = self.to_json()
        dc = json.loads(j)
        del dc['_id']
        return dc


class system_api(Document):
    uid = db_mongo.SequenceField(primary_key=True)  # 自增id
    api_url = db_mongo.StringField()
    api_method = db_mongo.StringField()
    api_module_desc = db_mongo.StringField()
    api_desc = db_mongo.StringField()

    def toDict(self):
        j = self.to_json()
        dc = json.loads(j)
        del dc['_id']
        return dc

    # def page_query(self,page_count=20,page=1):
    #     '''
    #     分页查询
    #     :param page_count:
    #     :param page:
    #     :return:
    #     '''
    #
    #     skip=page_count*(page-1)
    #     return self.find.limit(page_count).skip(skip)
