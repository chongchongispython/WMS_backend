from sqlalchemy import UniqueConstraint

from app import db
from app.model import createAndUpdateMixin, base_model
from app.util.enums import enum_task_type


class MainTask(db.Model, createAndUpdateMixin, base_model):
    __tablename__ = 'wms_main_task'
    __table_args__ = (
        UniqueConstraint("phase_id", "task_name", "task_type"),
    )

    id = db.Column(db.Integer, primary_key=True)
    phase_id = db.Column(db.ForeignKey("wms_phase.id"), nullable=False)
    task_name = db.Column(db.String(64), nullable=False)
    task_type = db.Column(db.Enum(enum_task_type), nullable=False)
    owner = db.Column(db.String(24), nullable=False)

    _sub_tasks = db.relationship("SubTask")
    _phase = db.relationship("Phase")
